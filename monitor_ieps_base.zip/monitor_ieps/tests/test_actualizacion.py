import datetime as dt
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from actualizar_mensual import periodo,construir
from actualizar_renuncias import extraer
from ejecutar_actualizacion import seleccionar

class Actualizaciones(unittest.TestCase):
 def test_mes_anterior_incluye_cambio_de_ano_y_bisiesto(self):
  self.assertEqual(periodo(dt.date(2026,1,10)),(dt.date(2025,12,1),dt.date(2025,12,31)))
  self.assertEqual(periodo(dt.date(2024,3,10)),(dt.date(2024,2,1),dt.date(2024,2,29)))
 def test_calendarios_no_consultan_en_push(self):
  self.assertEqual(seleccionar('push','',''),'publicar')
  self.assertEqual(seleccionar('schedule','0 15 10 * *',''),'mensual')
  self.assertEqual(seleccionar('schedule','0 15 1 7 *',''),'renuncias')
 def test_complementario_se_resta_a_cuota_positiva_y_admite_negativa(self):
  prices={('2026-09-01',f):25 for f in ('regular','premium','diesel')}
  rows=[dict(inicio='2026-09-01',fin='2026-09-01',combustible=f,cuota=1,complementario=2,cuota_completa=6,estimulo_pct=80,estimulo_monto=5,publicacion='2026-08-28',url_dof='https://dof.gob.mx/',edicion='MAT',categoria_original=f) for f in ('regular','premium','diesel')]
  result=construir(prices,rows,dt.date(2026,9,1),dt.date(2026,9,1))
  self.assertTrue(all(r['cuota']==-1 and r['neto']==26 for r in result))
  with self.assertRaises(ValueError):construir({},rows,dt.date(2026,9,1),dt.date(2026,9,1))
  rows[0]['complementario']=None
  with self.assertRaises(ValueError):construir(prices,rows,dt.date(2026,9,1),dt.date(2026,9,1))
 def test_efdp_total_no_suma_desgloses_ni_toma_columna_futura(self):
  text='2026 2027\nEF.DP.1 Estímulos fiscales en materia del IEPS aplicables a los combustibles automotrices 28,711 9,672 0.0769 0.0243\na. A los contribuyentes 19,044 7,000 0.05 0.01'
  self.assertEqual(extraer(text,2026),(28711,.0769))
  with self.assertRaises(ValueError):extraer('2026 EF.DP.1 combustibles 28,711 0.0769',2026)
if __name__=='__main__':unittest.main()
