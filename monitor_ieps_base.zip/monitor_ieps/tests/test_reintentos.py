import datetime as dt,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from calendario_actualizacion import inicial,mes_despues,planificar,registrar
class Reintentos(unittest.TestCase):
 def test_recupera_mes_si_no_corrio_el_dia_diez(self):
  e=inicial();t=planificar(e,dt.date(2026,10,20))[0]
  self.assertEqual(t['periodo'],'2026-09')
  self.assertEqual(t['referencia'],'2026-10-10')
  self.assertEqual(t['inicio'],'2026-10-20')
 def test_mes_calendario(self):
  self.assertEqual(mes_despues(dt.date(2027,1,31)),dt.date(2027,2,28))
 def test_periodo_fijo_y_limite(self):
  e=inicial();t=planificar(e,dt.date(2026,10,10))[0]
  registrar(e,t,dt.datetime(2026,10,10,9),error='sin datos')
  self.assertEqual(planificar(e,dt.date(2026,10,10)),[])
  retry=planificar(e,dt.date(2026,11,1))[0]
  self.assertEqual(retry['periodo'],'2026-09');self.assertEqual(retry['referencia'],'2026-10-10')
  planificar(e,dt.date(2026,11,10));self.assertEqual(t['estado'],'agotado')
 def test_exito_cancela_y_falla_no_cambia_fecha(self):
  e=inicial();t=planificar(e,dt.date(2026,10,10))[0]
  registrar(e,t,dt.datetime(2026,10,10,9),error='sin datos')
  self.assertEqual(e['ultima_actualizacion_datos'],'2026-10-09')
  registrar(e,t,dt.datetime(2026,10,11,9))
  self.assertEqual(planificar(e,dt.date(2026,10,12)),[])
  self.assertEqual(e['ultima_actualizacion_datos'],'2026-10-11T09:00:00')
if __name__=='__main__':unittest.main()

class FallaConsulta(unittest.TestCase):
 def test_falla_publica_aviso_sin_sustituir_base(self):
  import tempfile,shutil,json,os,subprocess
  from unittest.mock import patch
  import ejecutar_actualizacion as runner
  import estado_dashboard
  original=runner.ROOT
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);shutil.copytree(original/'data',root/'data')
   shutil.copyfile(original/'index.html',root/'index.html')
   antes=(root/'data/master.json').read_bytes()
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   fecha_anterior=json.loads((root/'data/estado_actualizacion.json').read_text())['ultima_actualizacion_datos']
   def consulta(script,*args):
    if script=='actualizar_mensual.py':
     (root/'data/master.json').write_text('base incompleta')
     raise subprocess.CalledProcessError(1,['consulta'])
   with patch.object(runner,'ROOT',root),patch.object(estado_dashboard,'ROOT',root),patch.object(runner,'run',side_effect=consulta),patch.dict(os.environ,{'EVENTO':'workflow_dispatch','CONSULTA':'mensual','FECHA_REFERENCIA':'2026-10-10','SOLO_PLAN':'0'}):
    runner.main()
   self.assertEqual((root/'data/master.json').read_bytes(),antes)
   e=json.loads((root/'data/estado_actualizacion.json').read_text())
   self.assertEqual(e['ultima_actualizacion_datos'],fecha_anterior)
   self.assertEqual(e['tareas']['mensual:2026-09']['estado'],'pendiente')
   self.assertIn('No se pudo actualizar el periodo 2026-09',(root/'index.html').read_text())

class CierreMensualTests(unittest.TestCase):
 def test_fechas_cierre(self):
  for fecha in [dt.date(2026,10,31),dt.date(2026,11,30),dt.date(2027,2,28),dt.date(2028,2,29)]:
   e=inicial();t=planificar(e,fecha);self.assertIn('recaudacion',[x['tipo'] for x in t])
 def test_antes_del_cierre(self):
  for fecha in [dt.date(2026,10,30),dt.date(2026,11,29),dt.date(2027,2,27)]:
   self.assertFalse(any(x['tipo']=='recaudacion' for x in planificar(inicial(),fecha)))
