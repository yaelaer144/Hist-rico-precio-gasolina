import datetime as dt,json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from actualizar_recaudacion import extraer,combinar
from descargar_presto import ultimo_cierre
from ejecutar_actualizacion import seleccionar
ROOT=Path(__file__).resolve().parents[1]

class Recaudacion(unittest.TestCase):
 def test_archivo_real_montos_conserva_negativos_y_alineacion_anual(self):
  values=extraer(ROOT/'raw/recaudacion/presto_montos_anuales_20261009.xls','Millones de pesos',2017,2025)
  self.assertEqual(values[2017],216498.69123)
  self.assertEqual(values[2022],-79162.067421)
  self.assertEqual(values[2025],444357.07672)
  with self.assertRaises(ValueError):extraer(ROOT/'raw/recaudacion/presto_montos_anuales_20261009.xls','Porcentajes del PIB',2017,2025)
 def test_calendario_diario(self):
  self.assertEqual(seleccionar('schedule','0 15 * * *',''),'programado')
 def test_corte_incompleto_no_se_convierte_en_cierre(self):
  self.assertEqual(ultimo_cierre('Información a Agosto de 2026')[0],2025)
  self.assertEqual(ultimo_cierre('Información a Diciembre de 2026')[0],2026)
  with self.assertRaises(ValueError):ultimo_cierre('No se publicó el corte')
 def test_dos_unidades_deben_cubrir_mismos_anos_y_ser_anuales(self):
  meta=dict(desde=2017,hasta=2017,periodicidad='Anual',cuadro='Pesos corrientes multianual',corte_oficial=dict(ano=2018,mes=1),consulta='Prueba sintética')
  base=[dict(ano=2017,recaudacion_mdp=1,recaudacion_pct_pib=.1),dict(ano=2018,recaudacion_mdp=None)]
  old=json.dumps(base);rows=combinar({2017:200},{2017:.7},meta,base)
  self.assertEqual(rows[0]['recaudacion_pct_pib'],.7)
  self.assertEqual(rows[0]['recaudacion_mdp'],200)
  self.assertEqual(json.dumps(base),old)
  with self.assertRaises(ValueError):combinar({2017:200},{},meta,base)
  with self.assertRaises(ValueError):combinar({2017:200},{2017:.7},{**meta,'periodicidad':'Mensual'},base)
  with self.assertRaises(ValueError):combinar({2026:200},{2026:.7},{**meta,'desde':2026,'hasta':2026,'corte_oficial':dict(ano=2026,mes=8)},base)
 def test_exportacion_porcentajes_no_recalcula_dato_publicado(self):
  # Valores ficticios para probar el lector; no se guardan en la base.
  content='''<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet><Table><Row><Cell><Data>Ingresos Presupuestarios del Sector Público, Porcentajes del PIB</Data></Cell></Row><Row><Cell><Data>Concepto</Data></Cell><Cell><Data>2017</Data></Cell></Row><Row><Cell><Data>IEPS gasolinas y diesel</Data></Cell><Cell><Data>0.7654</Data></Cell></Row><Row><Cell><Data>IEPS distinto de gasolinas y diesel</Data></Cell><Cell><Data>0.2222</Data></Cell></Row></Table></Worksheet></Workbook>'''
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'prueba.xls';p.write_text(content)
   self.assertEqual(extraer(p,'Porcentajes del PIB',2017,2017),{2017:.7654})
if __name__=='__main__':unittest.main()
