import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from recaudacion_mensual import pendientes,incorporar
class Backfill(unittest.TestCase):
 def test_recupera_febrero_hasta_agosto_sin_repetir_enero(self):
  data=[{'ano':2025,'mes':m,'acumulado_mdp':m} for m in range(1,13)]+[{'ano':2026,'mes':1,'acumulado_mdp':1}]
  self.assertEqual(pendientes(data,2026,8),[(2026,m) for m in range(2,9)])
 def test_al_cambiar_de_ano_recupera_enero_2027(self):
  data=[{'ano':2026,'mes':m,'acumulado_mdp':m} for m in range(1,13)]
  self.assertEqual(pendientes(data,2027,1),[(2027,1)])
 def test_orden_recuperacion_mes_a_mes(self):
  existing=[{'ano':2026,'mes':1,'acumulado_mdp':1}]
  current=[x for x in pendientes(existing,2026,9) if x[0]==2026]
  self.assertEqual(current,[(2026,m) for m in range(2,10)])
 def test_no_duplica_cortes(self):
  a=[{'ano':2026,'mes':1,'acumulado_mdp':3}]
  self.assertEqual(incorporar(a,[{'ano':2026,'mes':1,'acumulado_mdp':4}]),[{'ano':2026,'mes':1,'acumulado_mdp':4}])
