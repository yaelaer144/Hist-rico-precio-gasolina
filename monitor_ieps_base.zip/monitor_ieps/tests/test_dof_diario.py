import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from actualizar_dof_diario import integrar
import datetime as dt

class DofDiario(unittest.TestCase):
 def test_sin_precio_con_cuota_verificada(self):
  base=[dict(fecha='2026-10-05',combustible='regular',precio=24)]
  acuerdo=dict(combustible='regular',inicio='2026-10-06',fin='2026-10-13',cuota=6,complementario=0.4,cuota_completa=6.5,estimulo_pct=2,estimulo_monto=0.5,publicacion='2026-10-05',url_dof='https://dof.gob.mx',edicion='MAT',categoria_original='regular')
  r=integrar(base,[acuerdo],dt.date(2026,10,13))
  self.assertEqual(r[-1]['fecha'],'2026-10-13')
  self.assertIsNone(r[-1]['precio'])
  self.assertAlmostEqual(r[-1]['cuota'],5.6)
  self.assertEqual(r[0]['precio'],24)
 def test_no_inventa_fecha_sin_acuerdo(self):
  base=[dict(fecha='2026-10-05',combustible='regular',precio=24)]
  self.assertEqual(integrar(base,[],dt.date(2026,10,13)),base)
