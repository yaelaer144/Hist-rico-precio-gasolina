// Interacción por año; las fuentes y notas permanecen fuera del área del dato.
function attachAnnualHover(id,unit){
 const root=document.getElementById(id);if(!root)return;
 const svg=root.querySelector('svg');if(!svg)return;
 root.style.position='relative';
 const tip=document.createElement('div');tip.className='tooltip annual-tooltip';root.appendChild(tip);
 const ns='http://www.w3.org/2000/svg',cursor=document.createElementNS(ns,'line');
 cursor.setAttribute('y1','25');cursor.setAttribute('y2','275');cursor.setAttribute('stroke','#8796a5');cursor.style.display='none';svg.appendChild(cursor);
 const points=[...svg.querySelectorAll('circle')];
 svg.onpointermove=e=>{
  const rect=svg.getBoundingClientRect(),px=(e.clientX-rect.left)*650/rect.width;
  if(px<90||px>625||!points.length){tip.style.display='none';cursor.style.display='none';return;}
  const point=points.reduce((best,p)=>Math.abs(+p.getAttribute('cx')-px)<Math.abs(+best.getAttribute('cx')-px)?p:best);
  const title=point.querySelector('title').textContent,split=title.indexOf(':');
  tip.textContent='';const strong=document.createElement('b');strong.textContent=title.slice(0,split);tip.append(strong,document.createElement('br'),title.slice(split+1).trim()+' '+unit);
  tip.style.display='block';tip.style.top=Math.max(0,e.clientY-root.getBoundingClientRect().top-65)+'px';
  tip.style.left=Math.max(0,Math.min(e.clientX-rect.left+12,rect.width-tip.offsetWidth))+'px';
  cursor.setAttribute('x1',point.getAttribute('cx'));cursor.setAttribute('x2',point.getAttribute('cx'));cursor.style.display='block';
 };
 svg.onpointerleave=()=>{tip.style.display='none';cursor.style.display='none';};
}
[['annualMoney','millones de pesos'],['annualGDP','% del PIB'],['renunciaMoney','millones de pesos'],['renunciaGDP','% del PIB']].forEach(([id,unit])=>attachAnnualHover(id,unit));
