"""Fuentes, cero y EF.DP.1 de años concluidos con porcentajes publicados por SHCP."""
from pathlib import Path
import json,csv,re
ROOT=Path(__file__).resolve().parents[1]
percent={2017: 0.3594, 2018: 0.4609, 2019: 0.3405, 2020: 0.0603, 2021: 0.301, 2022: 1.13563, 2023: 0.87657, 2024: 0.0777, 2025: 0.052, 2026: 0.0769}
values={2017:74910,2018:107816,2019:84722,2020:14703,2021:76019,2022:328393,2023:272634,2024:26357,2025:18673,2026:28711}
rows=[]
for y,v in values.items():
 edition=2022 if y==2023 else y
 prefix='pgf' if edition<=2020 else 'drr'
 rows.append(dict(ano=y,renuncia_mdp=v,renuncia_pct_pib=percent[y],concepto='EF.DP.1 total',edicion=edition,estado='Estimación SHCP para año en curso' if y==2026 else 'Estimación SHCP para año concluido',fuente=f'https://www.finanzaspublicas.hacienda.gob.mx/work/models/Finanzas_Publicas/docs/congreso/infoanual/{edition}/{prefix}_{edition}.pdf',fuente_pib=f'https://www.finanzaspublicas.hacienda.gob.mx/work/models/Finanzas_Publicas/docs/congreso/infoanual/{edition}/{prefix}_{edition}.pdf',nota='Total EF.DP.1. Porcentaje del PIB transcrito de la columna del mismo año de la misma edición SHCP; no recalculado.'))

# Las consultas programadas actualizan esta base; no sobrescribirla con constantes.
if (ROOT/'data/renuncias_recaudatorias.json').exists():
 rows=sorted(json.loads((ROOT/'data/renuncias_recaudatorias.json').read_text()),key=lambda r:r['ano'])

(ROOT/'data/renuncias_recaudatorias.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
with (ROOT/'data/renuncias_recaudatorias.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
for path in [ROOT/'src/plantilla.html',ROOT/'index.html']:
 h=path.read_text()
 h=h.replace('Fuente: precios CNE/CRE y cuotas DOF (2017–2023); Excel proporcionado (2024–2026, sin reverificación). Precio menos cuota: cálculo propio, incluye estímulo complementario.','Fuente: precios CNE/CRE y cuotas DOF (2017–2026).')
 h=h.replace('Precio · MXN/litro</text>','Eje izquierdo: precios · MXN/litro</text>').replace('Cuotas IEPS · MXN/litro</text>','Eje derecho: cuotas IEPS · MXN/litro</text>')
 if 'data-zero-axis' not in h:
  needle='root.innerHTML=`<svg viewBox='
  insert='for(const [axis,side] of [[left,false],[rightAxis,true]]){if(axis.min<=0&&axis.max>=0)svg+=`<line data-zero-axis="${side?\'right\':\'left\'}" x1="${L}" x2="${W-R}" y1="${y(0,side)}" y2="${y(0,side)}" stroke="#000" stroke-width="1.8"/>`;} '
  h=h.replace(needle,insert+needle)
 h=h.replace('<div class="tooltip"></div>`','<div class="tooltip"></div><p class="small chart-source">Fuente: precios CNE/CRE y cuotas DOF (2017–2026).</p>`')
 h=h.replace('if(lo<0&&hi>0)','if(lo<=0&&hi>=0)').replace('stroke="#59687c"','stroke="#000" stroke-width="1.8"')
 h=h.replace('return s+\'</svg>\'}','return s+\'</svg><p class="small chart-source">Fuente: SHCP/Presto, IEPS gasolinas y diésel. Montos anuales 2017–2025: Excel exportado el 9 octubre 2026. Porcentajes del PIB: exportación previa; periodicidad anual pendiente de cotejo. 2026 pendiente.</p>\'}')
 if path.name=='index.html':
  h=re.sub(r'<!-- RENUNCIAS_OBSERVADAS -->.*?<!-- FIN_RENUNCIAS_OBSERVADAS -->','',h,flags=re.S)
  section='''<!-- RENUNCIAS_OBSERVADAS --><section id="renuncias" style="margin-top:28px"><h2>Renuncias recaudatorias</h2><p class="small">EF.DP.1 total · 2017–2026 · Estimaciones SHCP; 2026 corresponde al año en curso</p><div class="annualgrid"><div class="card annualplot"><div class="panel-top"><h3>Renuncias recaudatorias · Millones de pesos</h3><button data-png="renunciaMoney">Exportar PNG</button></div><div id="renunciaMoney"></div></div><div class="card annualplot"><div class="panel-top"><h3>Renuncias recaudatorias respecto al PIB · %</h3><button data-png="renunciaGDP">Exportar PNG</button></div><div id="renunciaGDP"></div></div></div><p class="small">Estimaciones de Renuncias Recaudatorias; 2026 es el año en curso. No son costos efectivamente observados. EF.DP.1 total. En 2023 se utiliza la edición 2022. Porcentajes del PIB publicados por SHCP en las mismas tablas EF.DP.1, sin recálculo.</p><div class="annualnav"><strong>Descargar base</strong><button id="renunciaCSV">CSV</button><button id="renunciaExcel">Excel</button></div></section><script>
const renunciasData=DATA;
function renunciaChart(field){let all=renunciasData,valid=all.filter(r=>Number.isFinite(r[field]));if(!valid.length)return '<p>Sin porcentaje oficial verificado.</p>';let scale=niceAnnualScale(valid.map(r=>r[field])),lo=scale.min,hi=scale.max;let W=650,H=330,L=90,R=25,T=25,B=55,x=r=>L+(r.ano-all[0].ano)*(W-L-R)/Math.max(1,all[all.length-1].ano-all[0].ano),y=v=>T+(hi-v)/(hi-lo)*(H-T-B),svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Renuncias recaudatorias EF.DP.1">`;for(let v of scale.ticks){svg+=`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="#dce4ed"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" font-size="12">${v.toLocaleString('es-MX',{maximumFractionDigits:field==='renuncia_mdp'?0:scale.decimals})}</text>`;}let d='',open=false;all.forEach(r=>{if(!Number.isFinite(r[field])){open=false;return;}d+=`${open?'L':'M'}${x(r)},${y(r[field])} `;open=true;});svg+=`<path d="${d}" fill="none" stroke="#183e72" stroke-width="3"/>`;all.forEach(r=>{svg+=`<text x="${x(r)}" y="${H-20}" text-anchor="middle" font-size="12">${r.ano}</text>`;if(Number.isFinite(r[field]))svg+=`<circle cx="${x(r)}" cy="${y(r[field])}" r="4" fill="#183e72"><title>${r.ano}: ${r[field].toLocaleString('es-MX',{maximumFractionDigits:field==='renuncia_pct_pib'?5:1})}</title></circle>`;});if(lo<=0&&hi>=0)svg+=`<line x1="${L}" x2="${W-R}" y1="${y(0)}" y2="${y(0)}" stroke="#000" stroke-width="1.8"/>`;return svg+'</svg><p class="small chart-source">Fuente: SHCP, Presupuesto de Gastos Fiscales / Renuncias Recaudatorias, EF.DP.1 total, ediciones 2017–2026 (2023: edición 2022). Porcentaje del PIB: columna publicada en la misma tabla y edición SHCP. Estimaciones SHCP; 2026 es año en curso.</p>';}
document.getElementById('renunciaMoney').innerHTML=renunciaChart('renuncia_mdp');document.getElementById('renunciaGDP').innerHTML=renunciaChart('renuncia_pct_pib');
document.getElementById('renunciaCSV').onclick=()=>{let keys=Object.keys(renunciasData[0]),q=v=>'"'+String(v??'').replaceAll('"','""')+'"',csv='\\ufeff'+[keys,...renunciasData.map(r=>keys.map(k=>r[k]))].map(r=>r.map(q).join(',')).join('\\r\\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='renuncias_recaudatorias_2017_2026.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
document.getElementById('renunciaExcel').onclick=()=>exportExcel(renunciasData,'renuncias_recaudatorias_2017_2026');
</script><!-- FIN_RENUNCIAS_OBSERVADAS -->'''.replace('DATA',json.dumps(rows,ensure_ascii=False))
  section=section.replace('2017–2026',f"{rows[0]['ano']}–{rows[-1]['ano']}").replace('2017_2026',f"{rows[0]['ano']}_{rows[-1]['ano']}").replace('2026 corresponde al año en curso','Incluye estimaciones publicadas para cada año').replace('2026 es el año en curso','Los montos son estimaciones fiscales').replace('2026 es año en curso','Cada registro conserva su edición y estado')
  h=h.replace('<!-- FIN_RECAUDACION_ANUAL -->','<!-- FIN_RECAUDACION_ANUAL -->'+section)
 if path.name=='index.html' and (ROOT/'data/actualizacion_recaudacion.json').exists():
  report=json.loads((ROOT/'data/actualizacion_recaudacion.json').read_text())
  if report.get('estado')=='Ambas unidades anuales verificadas':
   h=h.replace('Fuente: SHCP/Presto, IEPS gasolinas y diésel. Montos anuales 2017–2025: Excel exportado el 9 octubre 2026. Porcentajes del PIB: exportación previa; periodicidad anual pendiente de cotejo. 2026 pendiente.',f"Fuente: SHCP/Presto, IEPS gasolinas y diésel. Consulta {report['consulta']}, periodicidad anual, {report['desde']}–{report['hasta']}. Millones de pesos y % del PIB publicados por SHCP; porcentaje sin recálculo.")
 if path.name=='index.html':
  h=re.sub(r'<!-- HOVER_ANUAL -->.*?<!-- FIN_HOVER_ANUAL -->','',h,flags=re.S)
  h+='<!-- HOVER_ANUAL --><script>'+(ROOT/'src/hover_anual.js').read_text()+'</script><!-- FIN_HOVER_ANUAL -->'
 path.write_text(h)
print(f'Ajustes aplicados; EF.DP.1: {len(rows)} años, estimaciones SHCP.')
