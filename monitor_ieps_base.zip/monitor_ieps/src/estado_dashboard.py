"""Añade fecha y avisos visibles sin modificar las bases de las gráficas."""
import datetime as dt,html,json,re
from zoneinfo import ZoneInfo
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def aplicar(estado):
 p=ROOT/'index.html';h=p.read_text()
 # La etiqueta refleja cuándo se generó el dashboard, no la última publicación de datos.
 ahora=dt.datetime.now(ZoneInfo('America/Mexico_City'))
 fecha=ahora.strftime('%d/%m/%Y, %H:%M')
 aviso='<div id="ultimaActualizacion" style="padding:12px 20px;background:#eef4fa;color:#183e72"><strong>Última actualización del dashboard: '+fecha+' hrs.</strong></div>'
 h=h.replace('<header',aviso+'<header',1)
 mensajes={}
 for tarea in estado['tareas'].values():
  if tarea['estado']=='completado' or not tarea.get('intentos'):continue
  texto='No se pudo actualizar el periodo '+tarea['periodo']+'. Se conservan los últimos datos disponibles. '
  texto+=('Se agotó el plazo de un mes de reintentos.' if tarea['estado']=='agotado' else 'Se reintentará diariamente hasta el '+dt.date.fromisoformat(tarea['limite']).strftime('%d/%m/%Y')+' (sin incluir ese día).')
  mensajes.setdefault(tarea['tipo'],[]).append(texto)
 script='''<script id="estadoActualizacion">
const avisosActualizacion=MENSAJES;
function mostrarAviso(id,tipo){const root=document.getElementById(id);if(!root)return;root.querySelectorAll('.aviso-actualizacion').forEach(n=>n.remove());(avisosActualizacion[tipo]||[]).forEach(texto=>{const p=document.createElement('p');p.className='small aviso-actualizacion';p.style.cssText='color:#a23e24;padding:10px 0;border-top:1px solid #e6ecf2';p.setAttribute('role','status');p.textContent=texto;root.appendChild(p);});}
const dibujarAnterior=draw;draw=function(k){dibujarAnterior(k);mostrarAviso('plot-'+k,'mensual');};
['regular','premium','diesel'].forEach(k=>mostrarAviso('plot-'+k,'mensual'));
['annualMoney','annualGDP'].forEach(id=>mostrarAviso(id,'recaudacion'));
['renunciaMoney','renunciaGDP'].forEach(id=>mostrarAviso(id,'renuncias'));
</script>'''.replace('MENSAJES',json.dumps(mensajes,ensure_ascii=False).replace('</','<\\/'))
 h+=script;p.write_text(h)
