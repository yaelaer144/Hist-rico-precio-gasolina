"""Extracción conservadora de la serie mensual acumulada de PRESTO.
Nunca modifica el histórico anual. Acepta una exportación verificada para pruebas locales.
"""
import argparse,calendar,csv,datetime as dt,hashlib,json,math,os,re
from pathlib import Path
from zoneinfo import ZoneInfo
from actualizar_recaudacion import leer_tabla
from descargar_presto import URL,norm,click_text,select_text,selects,frames
ROOT=Path(__file__).resolve().parents[1]
MESES=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre']

def numero(s):
 if isinstance(s,(float,int)):return float(s)
 s=str(s).replace(',','').replace('−','-').replace(' ','').strip()
 if s.startswith('(') and s.endswith(')'):s='-'+s[1:-1]
 if not re.fullmatch(r'-?\d+(?:\.\d+)?',s):raise ValueError('Dato no numérico')
 val=float(s)
 if not math.isfinite(val):raise ValueError('Dato no finito')
 return val

def interpretar(path, years):
 """Lee una exportación PRESTO: corte acumulado de un mes, o tabla con meses explícitos.

 Los archivos "Enero (2025-2026) ... (Flujos Acumulados)" NO son flujos
 mensuales para sumarse: cada columna representa el acumulado hasta enero.
 """
 rows=leer_tabla(path)
 if not rows:raise ValueError('Exportación vacía')
 title=norm(' '.join(str(v) for v in rows[0]))
 if 'ingresos presupuestarios del sector publico' not in title:raise ValueError('No coincide el cuadro de ingresos')
 if 'millones de pesos' not in title:raise ValueError('La exportación no dice millones de pesos')
 candidates=[row for row in rows if row and norm(row[0]).strip() in ('ieps gasolinas y diesel','no petroleros: ieps gasolinas y diesel')]
 if len(candidates)!=1:raise ValueError('La fila IEPS gasolinas y diésel no es única')
 row=candidates[0]
 if 'flujos acumulados' in title:
  matches=[(m+1,y) for m,name in enumerate(MESES) for y in re.findall(r'\b'+name+r'\s*\((20\d{2})\s*[-–]\s*20\d{2}\)',title)]
  if len(matches)!=1:
   # Variante: «Enero (2025-2026)»; usar mes del título y años de la cabecera.
   months=[i+1 for i,name in enumerate(MESES) if re.search(r'\b'+name+r'\b',title)]
   if len(months)!=1:raise ValueError('Mes acumulado no identificado en título')
   month=months[0]
  else:month=matches[0][0]
  yearheaders=[]
  for h in rows[1:8]:
   options={j:int(str(v).strip()) for j,v in enumerate(h) if re.fullmatch(r'20\d{2}',str(v).strip())}
   if options:yearheaders.append(options)
  if len(yearheaders)!=1:raise ValueError('Columnas de años ambiguas')
  out=[]
  for j,year in yearheaders[0].items():
   if year not in years or j>=len(row) or not str(row[j]).strip():continue
   out.append({'ano':year,'mes':month,'acumulado_mdp':round(numero(row[j]),5)})
  if not out:raise ValueError('Sin valores de los años solicitados')
  return out
 # Otro formato: columnas individuales con año y mes. Si son flujos mensuales,
 # acumularlos dentro del año; NO acumular tablas que ya indiquen flujos acumulados.
 header=norm(' '.join(str(x) for r in rows[:14] for x in r))
 if 'mensual' not in header:raise ValueError('No consta periodicidad mensual')
 idx=rows.index(row);cols={}
 for j in range(max(len(r) for r in rows[:idx+1])):
  strings=[norm(r[j]) for r in rows[max(0,idx-6):idx] if len(r)>j]
  choices=set()
  for st in strings+[norm(' '.join(strings[-2:]))]:
   ys=[int(x) for x in re.findall(r'(?<!\d)20\d{2}(?!\d)',st) if int(x) in years]
   ms=[k+1 for k,name in enumerate(MESES) if re.search(r'\b'+name+r'\b',st)]
   if len(ys)==1 and len(ms)==1:choices.add((ys[0],ms[0]))
  if len(choices)==1:
   key=choices.pop()
   if key in cols:raise ValueError('Mes duplicado')
   cols[key]=j
 if not cols:raise ValueError('No hay meses identificables en la exportación')
 data=[]
 for (year,month),j in sorted(cols.items()):
  if j<len(row) and str(row[j]).strip():data.append({'ano':year,'mes':month,'valor':numero(row[j])})
 for year in years:
  mm=[r['mes'] for r in data if r['ano']==year]
  if mm and mm!=list(range(1,max(mm)+1)):raise ValueError('Meses discontinuos')
  total=0
  for r in (r for r in data if r['ano']==year):
   total+=r.pop('valor');r['acumulado_mdp']=round(total,5)
 return data

def descargar(destino,year):
 from playwright.sync_api import sync_playwright
 destino=Path(destino);destino.parent.mkdir(parents=True,exist_ok=True)
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True);context=browser.new_context(accept_downloads=True);page=context.new_page()
  try:
   page.set_default_timeout(20000);response=page.goto(URL,wait_until='domcontentloaded',timeout=60000)
   if response and response.status>=400:raise ValueError('PRESTO HTTP '+str(response.status))
   click_text(page,r'^Reportes$',required=False)
   for label in [r'^Ingreso,?\s*gasto y financiamiento(?: del sector p[uú]blico)?$',r'^Ingresos presupuestarios$',r'^Ingresos presupuestarios del sector p[uú]blico$']:click_text(page,label)
   select_text(page,'Pesos corrientes multianual');select_text(page,'Mensual');select_text(page,'Millones de pesos')
   # Algunas versiones de PRESTO ofrecen un selector del mes de corte.
   # Utilizar el mes más reciente disponible, sin suponer que el mes actual ya se publicó.
   month_controls=[]
   for loc,opts in selects(page):
    options=[(i+1,o) for i,name in enumerate(MESES) for o in opts if norm(o['text'])==name]
    if len(options)>=8:month_controls.append((loc,options))
   if len(month_controls)==1:
    loc,options=month_controls[0]
    published=[(m,opt) for m,opt in options if (year, m)<= (dt.datetime.now(ZoneInfo('America/Mexico_City')).year, dt.datetime.now(ZoneInfo('America/Mexico_City')).month)]
    if published:loc.select_option(value=max(published,key=lambda z:z[0])[1]['value']);page.wait_for_timeout(300)
   controls=[]
   for loc,options in selects(page):
    vals={norm(o['text']):o['value'] for o in options}
    if str(year-1) in vals and str(year) in vals and sum(bool(re.fullmatch(r'20\d{2}',k)) for k in vals)>=2:controls.append((loc,vals))
   if len(controls)!=2:raise ValueError('Selectores de intervalo anual ambiguos')
   controls[0][0].select_option(value=controls[0][1][str(year-1)]);page.wait_for_timeout(300)
   controls=[]
   for loc,options in selects(page):
    vals={norm(o['text']):o['value'] for o in options}
    if str(year-1) in vals and str(year) in vals and sum(bool(re.fullmatch(r'20\d{2}',k)) for k in vals)>=2:controls.append((loc,vals))
   if len(controls)!=2:raise ValueError('Selectores cambiaron')
   controls[1][0].select_option(value=controls[1][1][str(year)])
   selected=[norm(loc.evaluate('(s)=>s.options[s.selectedIndex].textContent')) for loc,_ in selects(page)]
   for x in ['Pesos corrientes multianual','Mensual','Millones de pesos',str(year-1),str(year)]:
    if norm(x) not in selected:raise ValueError('No se confirmó '+x)
   with page.expect_download(timeout=60000) as info:click_text(page,r'^Consultar\s*(?:y|&)\s*descargar$')
   download=info.value
   if download.failure():raise ValueError('Descarga fallida')
   download.save_as(str(destino))
  except Exception:
   folder=ROOT/'diagnostico_presto';folder.mkdir(exist_ok=True)
   page.screenshot(path=str(folder/'error_mensual.png'),full_page=True)
   (folder/'error_mensual.html').write_text(page.content())
   raise
  finally:context.close();browser.close()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--archivo');ap.add_argument('--ano',type=int);ap.add_argument('--dry-run',action='store_true');args=ap.parse_args()
 now=dt.datetime.now(ZoneInfo('America/Mexico_City'))
 year=args.ano or now.year
 if year<2017 or year>now.year:raise ValueError('Año inválido')
 file=Path(args.archivo) if args.archivo else ROOT/'diagnostico_presto'/'mensual.xls'
 if not args.archivo:descargar(file,year)
 values=interpretar(file,{year-1,year})
 if not args.archivo and not any(v['ano']==year for v in values):raise ValueError('PRESTO aún no publicó cifras del año '+str(year))
 for v in values:
  if (v['ano'],v['mes'])>(now.year,now.month):raise ValueError('Dato futuro')
 path=ROOT/'data/recaudacion_mensual.json'
 previous=json.loads(path.read_text()) if path.exists() else []
 bykey={(v['ano'],v['mes']):v for v in previous}
 for v in values:bykey[v['ano'],v['mes']]=v
 # Al consultar automáticamente, PRESTO debe traer al menos un periodo nuevo.
 # Si aún no publica datos, la cola conservará el pendiente para el reintento diario.
 if not args.archivo and not any((v['ano'],v['mes']) not in {(r['ano'],r['mes']) for r in previous} for v in values):
  raise ValueError('PRESTO todavía no publicó un periodo mensual nuevo; reintentar')
 result=sorted(bykey.values(),key=lambda r:(r['ano'],r['mes']))
 report={'estado':'validado','fuente':URL,'serie':'No petroleros: IEPS gasolinas y diésel','cuadro':'Pesos corrientes multianual','periodicidad':'mensual','unidad':'millones de pesos','fecha_consulta':now.isoformat(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'ultimo_periodo':max((v['ano'],v['mes']) for v in values),'filas':len(values)}
 if args.dry_run:print(json.dumps(report,ensure_ascii=False));return
 path.write_text(json.dumps(result,ensure_ascii=False,indent=2))
 (ROOT/'data/recaudacion_mensual_estado.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 with (ROOT/'data/recaudacion_mensual.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=['ano','mes','acumulado_mdp']);writer.writeheader();writer.writerows(result)
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
