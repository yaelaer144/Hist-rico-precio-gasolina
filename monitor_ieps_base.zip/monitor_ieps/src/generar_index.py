"""Construye dashboard local a partir de plantilla y master; embebe descargas."""
from pathlib import Path
import json,base64,re
ROOT=Path(__file__).resolve().parents[1]
def generate():
 s=(ROOT/'src/plantilla.html').read_text();data=(ROOT/'data/master.json').read_text();xlsx=base64.b64encode((ROOT/'historico_validado.xlsx').read_bytes()).decode();coverage=json.loads((ROOT/'data/cobertura.json').read_text());historical=[r for r in coverage if r['ano']<=2023]
 missing=sum(r['dias_esperados']-r['dias_completos'] for r in historical)
 # Codificación columnar: evita repetir nombres de campos y textos idénticos por día.
 rows=json.loads(data)
 keys=list(rows[0]) if rows else []
 dicts={}
 packed=[]
 for k in keys:
  if any(isinstance(r.get(k),str) for r in rows):
   uniq=list(dict.fromkeys(r.get(k) for r in rows))
   if len(uniq)<len(rows)*0.60:
    dicts[k]=uniq
 for r in rows:
  packed.append([dicts[k].index(r.get(k)) if k in dicts else r.get(k) for k in keys])
 payload=json.dumps({'k':keys,'d':dicts,'r':packed},ensure_ascii=False,separators=(',',':'))
 unpack="const _compactData="+payload+";\nconst embeddedData=_compactData.r.map(row=>Object.fromEntries(_compactData.k.map((key,i)=>[key,Object.prototype.hasOwnProperty.call(_compactData.d,key)?_compactData.d[key][row[i]]:row[i]])));\nfunction load"
 s=re.sub(r'const embeddedData=.*?;\nfunction load',lambda m:unpack,s,flags=re.S)
 s=re.sub(r'href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,[^"]+"',lambda m:'href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'+xlsx+'"',s)
 s=s.replace('2017–2023: sin datos disponibles.</b> El eje temporal empieza en 2017, pero las series de este archivo comienzan en enero de 2024. No se estimaron ni rellenaron los años faltantes.',f'Histórico 2017–2023 cargado desde fuentes oficiales.</b> Precios nacionales diarios CNE/CRE y cuotas DOF por vigencia. Registros sin combinación completa: {missing}. No se interpolan valores faltantes.')
 s=s.replace('Gasolina menor a 91 octanos','Gasolina regular').replace('Gasolina ≥91 octanos','Gasolina premium')
 s=s.replace('Versión inicial · Histórico del Excel','Histórico desde 2017').replace('Archivo local · Histórico del Excel','Archivo local · Histórico desde 2017')
 s=s.replace('Las cuotas se importaron del Excel y algunas proceden de cálculos con porcentajes redondeados. Esta versión todavía no las ha cotejado con cada acuerdo original del DOF.', 'Para 2017–2023 las cuotas se extrajeron directamente de documentos DOF y se conservaron sus URLs. Para 2024–2026 se mantienen las cuotas del Excel inicial, sin reverificación. Los documentos fiscales antiguos clasifican gasolina por 92 octanos; desde 2020 por 91. La descarga conserva la categoría original.')
 s=s.replace('Histórico inicial: <b>ieps gasolina.xlsx</b> proporcionado por el usuario. Las consultas a las fuentes oficiales no pudieron completarse durante esta publicación.', 'Precios 2017–2023: archivo oficial CNE/CRE, hoja <b>Cuadro 1.1</b>. Cuotas: acuerdos y decretos originales del DOF. Desde 2024 se integra el Excel inicial y se conserva la procedencia de cada componente.')
 s=s.replace('Publicación inicial: 5 de octubre de 2026. Las descargas incluyen origen, estímulos y fechas de publicación disponibles en el archivo.', 'Carga histórica: 6 de octubre de 2026. Las descargas incluyen cobertura por año, fechas faltantes, URLs DOF y notas de validación. Corte del histórico inicial: 5 de octubre de 2026.')
 table='<details><summary>Cobertura histórica 2017–2023</summary><div class="tablewrap"><table><thead><tr><th>Año</th><th>Días esperados</th><th>Con precio</th><th>Con cuota DOF</th></tr></thead><tbody>'
 for r in historical:
  if r['combustible']!='regular':continue
  table+=f"<tr><td>{r['ano']}</td><td>{r['dias_esperados']}</td><td>{r['dias_precio']}</td><td>{r['dias_cuota_dof']}</td></tr>"
 table+='</tbody></table></div><p class="small">Cobertura de regular; el Excel incluye los tres combustibles y las advertencias por registro.</p></details>'
 s=s.replace('<details><summary>Ver datos',table+'<details><summary>Ver datos')
 # Fechas independientes: CNE exige los tres combustibles, DOF solo cuota.
 from collections import defaultdict
 import datetime as dt
 fuel_dates=defaultdict(set)
 fiscal_dates=[]
 for row in rows:
  if row.get('precio') is not None and row.get('combustible') in ('regular','premium','diesel'):
   fuel_dates[row['fecha']].add(row['combustible'])
  if row.get('cuota') is not None:
   fiscal_dates.append(row['fecha'])
 valid_prices=[date for date,fuels in fuel_dates.items() if len(fuels)==3]
 if not valid_prices:raise ValueError('No hay fecha con precios completos CNE')
 price_end=max(valid_prices)
 fiscal_end=max(fiscal_dates) if fiscal_dates else None
 data_end=max(price_end,fiscal_end or price_end)
 meses=('enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre')
 def display_date(iso):
  date=dt.date.fromisoformat(iso)
  return f'{date.day} de {meses[date.month-1]} de {date.year}'
 # Limites de ambos calendarios, pero vista inicial hasta CNE.
 s=re.sub(r'(<input\s+id="(?:start|end)"[^>]*?\smax=")[^"]+"',lambda m:m.group(1)+data_end+'"',s)
 s=re.sub(r'(<input\s+id="end"[^>]*?\svalue=")[^"]+"',lambda m:m.group(1)+price_end+'"',s)
 # Avisos independientes generados desde los datos (no fechas fijas).
 s=re.sub(r'Los precios disponibles terminan el\s*<b>.*?</b>\.', 'Los precios disponibles terminan el <b>'+display_date(price_end)+'</b>.', s, count=1, flags=re.S)
 if fiscal_end:
  s=re.sub(r'(?:El Excel contiene cuotas hasta el corte del|Las cuotas disponibles llegan hasta el)\s*<b>.*?</b>\.', 'Las cuotas disponibles llegan hasta el <b>'+display_date(fiscal_end)+'</b>.', s, count=1, flags=re.S)
 print('CNE: precios hasta', price_end, '| DOF: cuotas hasta', fiscal_end)

 s=s.replace('EXPORT_HELPERS',(ROOT/'src/exportaciones.js').read_text())
 (ROOT/'index.html').write_text(s)
 print('Index generado; registros faltantes 2017–2023:',missing)
if __name__=='__main__':generate()
