"""EF.DP.1 total y porcentaje publicado del mismo año; falla sin alterar datos."""
import argparse,datetime as dt,hashlib,json,os,re,urllib.request
from pathlib import Path
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
URL2026='https://www.gob.mx/cms/uploads/attachment/file/1086727/DRR_2026.pdf'
def extraer(texto,ano):
 # La fila tiene cuatro columnas: monto del año, monto siguiente, % año, % siguiente.
 candidates=[]
 for match in re.finditer(r'EF\s*\.\s*DP\s*\.\s*1\b',texto,re.I):
  context=texto[max(0,match.start()-5000):match.start()+1800]
  if str(ano) not in context or str(ano+1) not in context:continue
  block=texto[match.end():match.end()+1800]
  block=re.split(r'\ba\s*\.\s+A los|EF\s*\.\s*DP\s*\.\s*2\b',block,flags=re.I)[0]
  if 'combustibles' not in block.lower():continue
  nums=re.findall(r'(?<![\w.])\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?<![\w.])\d+\.\d+|(?<![\w.])\d+(?![\w.])',block)
  if len(nums)!=4:continue
  vals=[float(x.replace(',','')) for x in nums]
  if vals[0]>=0 and 0<=vals[2]<=100:candidates.append((vals[0],vals[2]))
 candidates=set(candidates)
 if len(candidates)!=1:raise ValueError('EF.DP.1 ambiguo o estructura distinta: requiere revisión; base conservada')
 return candidates.pop()
def main():
 p=argparse.ArgumentParser();p.add_argument('--ano',type=int,default=dt.date.today().year);p.add_argument('--pdf');p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 url=URL2026 if a.ano==2026 else f'https://www.finanzaspublicas.hacienda.gob.mx/work/models/Finanzas_Publicas/docs/congreso/infoanual/{a.ano}/drr_{a.ano}.pdf'
 b=Path(a.pdf).read_bytes() if a.pdf else urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MonitorIEPS/1.0'}),timeout=60).read()
 if not b.startswith(b'%PDF'):raise ValueError('No se descargó un PDF oficial; base conservada')
 import io
 texto='\n'.join(page.extract_text(extraction_mode='layout') or '' for page in PdfReader(io.BytesIO(b)).pages)
 monto,pct=extraer(texto,a.ano)
 row=dict(ano=a.ano,renuncia_mdp=monto,renuncia_pct_pib=pct,concepto='EF.DP.1 total',edicion=a.ano,estado='Estimación SHCP para año en curso' if a.ano==dt.date.today().year else 'Estimación SHCP para año concluido',fuente=url,fuente_pib=url,nota=f'Total EF.DP.1 de edición {a.ano}, columna {a.ano}; porcentaje publicado por SHCP, no recalculado.')
 if a.dry_run:print(json.dumps(row,ensure_ascii=False));return
 target=ROOT/'data/renuncias_recaudatorias.json';rows=json.loads(target.read_text());rows=[r for r in rows if r['ano']!=a.ano]+[row];rows.sort(key=lambda r:r['ano'])
 tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2));os.replace(tmp,target)
 (ROOT/'raw'/f'drr_{a.ano}.pdf').write_bytes(b)
 (ROOT/'data/actualizacion_renuncias.json').write_text(json.dumps(dict(consulta=dt.datetime.now(dt.timezone.utc).isoformat(),fuente=url,sha256=hashlib.sha256(b).hexdigest(),ano=a.ano),indent=2))
 print(json.dumps(row,ensure_ascii=False))
if __name__=='__main__':main()
