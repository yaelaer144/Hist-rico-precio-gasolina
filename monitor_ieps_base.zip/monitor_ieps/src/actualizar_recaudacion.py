"""Actualiza conjuntamente monto anual y % PIB oficiales. No calcula el porcentaje."""
import argparse,csv,datetime as dt,hashlib,io,json,math,os,re,tempfile
from pathlib import Path
from zoneinfo import ZoneInfo
from lxml import etree,html
from descargar_presto import descargar,norm,URL
ROOT=Path(__file__).resolve().parents[1]
SS='urn:schemas-microsoft-com:office:spreadsheet'

def leer_tabla(path):
 b=Path(path).read_bytes()
 if b.startswith(b'PK'):
  import openpyxl
  w=openpyxl.load_workbook(io.BytesIO(b),read_only=True,data_only=True)
  rows=[[str(v).strip() if v is not None else '' for v in row] for row in w.active.iter_rows(values_only=True)];w.close();return rows
 if b.startswith(bytes.fromhex('D0CF11E0')):
  import xlrd
  sheet=xlrd.open_workbook(file_contents=b).sheet_by_index(0);return [[str(v).strip() for v in sheet.row_values(i)] for i in range(sheet.nrows)]
 s=b.decode('utf-8','surrogateescape')
 s=''.join(bytes([ord(c)-0xdc00]).decode('cp1252',errors='replace') if 0xdc80<=ord(c)<=0xdcff else c for c in s)
 if 'urn:schemas-microsoft-com:office:spreadsheet' in s:
  t=etree.fromstring(s.encode('utf-8'),etree.XMLParser(resolve_entities=False,no_network=True));rows=[]
  for tr in t.findall('.//{'+SS+'}Row'):
   row=[];column=0
   for cell in tr.findall('{'+SS+'}Cell'):
    column=int(cell.get('{'+SS+'}Index',column+1))-1
    while len(row)<=column:row.append('')
    data=cell.find('{'+SS+'}Data');row[column]=''.join(data.itertext()).strip() if data is not None else ''
    column+=int(cell.get('{'+SS+'}MergeAcross',0))+1
   rows.append(row)
  return rows
 t=html.fromstring(s);return [[' '.join(c.itertext()).strip() for c in tr.xpath('./th|./td')] for tr in t.xpath('//tr')]

def extraer(path,unit,desde,hasta):
 rows=leer_tabla(path);header=norm(' '.join(v for row in rows[:4] for v in row))
 if 'ingresos presupuestarios del sector publico' not in header or norm(unit) not in header:raise ValueError('Cuadro o unidad incorrectos en '+str(path))
 if re.search(r'\bmensual\b|\btrimestral\b',header):raise ValueError('La exportación no es anual')
 years=[]
 for i,row in enumerate(rows):
  cols={c:int(v) for c,v in enumerate(row) if re.fullmatch(r'20\d{2}(?:\.0)?',str(v)) for v in [str(v).removesuffix('.0')]}
  if set(cols.values())==set(range(desde,hasta+1)):years.append((i,cols))
 if len(years)!=1:raise ValueError('Columnas anuales incompletas o ambiguas')
 i,cols=years[0]
 candidates=[row for row in rows[i+1:] if any(norm(v).startswith('ieps gasolinas y diesel') for v in row)]
 if len(candidates)!=1:raise ValueError('No se encontró una sola fila IEPS gasolinas y diésel')
 row=candidates[0];values={}
 for col,year in cols.items():
  if col>=len(row):raise ValueError('Año sin valor: '+str(year))
  raw=str(row[col]).replace(',','').replace('−','-').strip()
  try:value=float(raw)
  except ValueError:raise ValueError('Valor anual faltante o no numérico: '+str(year))
  if not math.isfinite(value):raise ValueError('Valor no finito')
  if unit=='Porcentajes del PIB' and abs(value)>100:raise ValueError('Unidad % PIB no coherente')
  values[year]=value
 return values

def combinar(montos,pcts,meta,base):
 years=set(range(meta['desde'],meta['hasta']+1))
 if set(montos)!=years or set(pcts)!=years:raise ValueError('Las unidades no cubren los mismos años')
 if norm(meta.get('periodicidad',''))!='anual' or meta.get('cuadro')!='Pesos corrientes multianual':raise ValueError('Filtros oficiales no confirmados')
 cut=meta['corte_oficial'];last=cut['ano'] if cut['mes']==12 else cut['ano']-1
 if meta['hasta']>last or meta['hasta']>=dt.datetime.now(ZoneInfo('America/Mexico_City')).year:raise ValueError('No usar acumulado parcial como cierre anual')
 byyear={r['ano']:dict(r) for r in base}
 for year in sorted(years):
  old=byyear.get(year,{})
  byyear[year]={**old,'ano':year,'recaudacion_mdp':montos[year],'recaudacion_pct_pib':pcts[year],'pib_nominal_mdp':None,'periodo':'Enero–diciembre','estado':'SHCP/Presto: ambas unidades, periodicidad anual confirmada','fuente_recaudacion':URL,'fuente_pib':URL,'nota':'Porcentaje del PIB publicado directamente por SHCP; no recalculado. Consulta '+meta['consulta'],'consulta':meta['consulta'],'cuadro':meta['cuadro'],'periodicidad':'Anual'}
 return sorted(byyear.values(),key=lambda r:r['ano'])

def main():
 p=argparse.ArgumentParser();p.add_argument('--montos');p.add_argument('--pib');p.add_argument('--metadata');p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 supplied=[a.montos,a.pib,a.metadata]
 if any(supplied) and not all(supplied):raise ValueError('Se requieren las dos exportaciones y sus filtros de consulta')
 if all(supplied):folder=None;montos,pib,metadata=map(Path,supplied)
 else:
  folder=ROOT/'diagnostico_presto';descargar(folder);montos,pib,metadata=folder/'montos.xls',folder/'pib.xls',folder/'consulta.json'
 meta=json.loads(metadata.read_text());m=extraer(montos,'Millones de pesos',meta['desde'],meta['hasta']);pct=extraer(pib,'Porcentajes del PIB',meta['desde'],meta['hasta'])
 base=json.loads((ROOT/'data/recaudacion_anual.json').read_text());rows=combinar(m,pct,meta,base)
 report={**meta,'anos_actualizados':sorted(m),'sha256_montos':hashlib.sha256(montos.read_bytes()).hexdigest(),'sha256_pib':hashlib.sha256(pib.read_bytes()).hexdigest(),'estado':'Ambas unidades anuales verificadas'}
 if a.dry_run:print(json.dumps(report,ensure_ascii=False,indent=2));return
 raw=ROOT/'raw/recaudacion';raw.mkdir(parents=True,exist_ok=True)
 stamp=dt.datetime.now(ZoneInfo('America/Mexico_City')).strftime('%Y%m%d_%H%M%S')
 for source,suffix in [(montos,'montos'),(pib,'pib'),(metadata,'consulta')]:
  (raw/f'presto_{stamp}_{suffix}{source.suffix}').write_bytes(source.read_bytes())
 target=ROOT/'data/recaudacion_anual.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2));os.replace(tmp,target)
 (ROOT/'data/actualizacion_recaudacion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 with (ROOT/'data/recaudacion_anual.csv').open('w',encoding='utf-8-sig',newline='') as f:
  keys=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
