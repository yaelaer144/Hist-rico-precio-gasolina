"""Integra fuentes con trazabilidad; no interpola huecos."""
import pathlib,json,datetime as dt,csv,openpyxl,collections,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
URL_PRICE='https://www.cne.gob.mx/da/Precios_promedio_diarios_y_mensuales_en_estaciones_de_servicio.xlsx'
def build():
 w=openpyxl.load_workbook(ROOT/'raw/precios.xlsx',data_only=True);prices={}
 for row in w['Cuadro 1.1'].values:
  try:d=dt.datetime.strptime(str(row[0]),'%d/%m/%Y').date()
  except (ValueError,TypeError):continue
  for k,fuel in enumerate(['regular','premium','diesel'],1):
   value=row[k]
   if isinstance(value,(int,float)) and value>0:prices[(d.isoformat(),fuel)]=value
 fiscal={};weekly=json.loads((ROOT/'data/ieps_semanal.json').read_text())
 if (ROOT/'data/ieps_especial_2017.json').exists():weekly+=json.loads((ROOT/'data/ieps_especial_2017.json').read_text())
 for r in weekly:
  d=dt.date.fromisoformat(r['inicio']);end=dt.date.fromisoformat(r['fin'])
  while d<=end:
   key=(d.isoformat(),r['combustible'])
   if key in fiscal and abs(fiscal[key]['cuota']-r['cuota'])>1e-6:raise ValueError('Cuotas incompatibles '+str(key))
   fiscal[key]=r;d+=dt.timedelta(days=1)
 base=json.loads((ROOT/'data/base_excel_inicial.json').read_text());existing={(r['fecha'],r['combustible']):r for r in base};out=[]
 dates=[dt.date(2017,1,1)+dt.timedelta(days=i) for i in range((dt.date(2026,10,5)-dt.date(2017,1,1)).days+1)]
 for d in dates:
  for fuel in ['regular','premium','diesel']:
   key=(d.isoformat(),fuel);old=existing.get(key,{});p=prices.get(key,old.get('precio'));f=fiscal.get(key);q=f['cuota'] if f else old.get('cuota')
   comp=f.get('complementario') if f else old.get('complementario')
   published=q
   applied_comp=comp if comp is not None else 0 if key[0]<'2022-03-05' else None
   q=round(published-applied_comp,8) if published is not None and applied_comp is not None else None
   r=dict(cuota_publicada=published,complementario_calculo=applied_comp,fecha=key[0],combustible=fuel,precio=p,cuota=q,neto=round(p-q,8) if p is not None and q is not None else None,estimulo_pct=f['estimulo_pct'] if f else old.get('estimulo_pct'),estimulo_monto=f['estimulo_monto'] if f else old.get('estimulo_monto'),complementario=f.get('complementario') if f else old.get('complementario'),cuota_completa=f['cuota_completa'] if f else old.get('cuota_completa'),publicacion=f['publicacion'] if f else old.get('publicacion'),fuente='CNE/CRE y DOF' if f and key in prices else 'CNE/CRE (precio); cuota pendiente' if key in prices and not old else old.get('fuente','Pendiente'),url_precio=URL_PRICE if key in prices else None,url_dof=f['url_dof'] if f else None,inicio_vigencia=f['inicio'] if f else None,fin_vigencia=f['fin'] if f else None,edicion=f['edicion'] if f else None,categoria_original=f['categoria_original'] if f else None,estado_cuota=('DOF extraído; advertencia en fuente' if f.get('nota','') and 'Inconsistencia' in f['nota'] else 'DOF extraído y validado') if f else 'Excel inicial sin reverificación' if old else 'Pendiente',nota=f.get('nota') if f else None)
   out.append(r)
 # Auditoria de cobertura diaria por ano.
 coverage=[];gaps=[]
 for year in range(2017,2027):
  for fuel in ['regular','premium','diesel']:
   subset=[r for r in out if r['fecha'].startswith(str(year)) and r['combustible']==fuel];missing=[r['fecha'] for r in subset if r['cuota'] is None]
   coverage.append(dict(ano=year,combustible=fuel,dias_esperados=len(subset),dias_precio=sum(r['precio'] is not None for r in subset),dias_cuota_dof=sum(r['estado_cuota'].startswith('DOF') for r in subset),dias_advertencia=sum('advertencia' in r['estado_cuota'] for r in subset),dias_cuota_excel=sum(r['estado_cuota']=='Excel inicial sin reverificación' for r in subset),dias_completos=sum(r['precio'] is not None and r['cuota'] is not None for r in subset)))
   for r in subset:
    if r['precio'] is None or r['cuota'] is None:gaps.append(dict(fecha=r['fecha'],combustible=fuel,falta_precio=r['precio'] is None,falta_cuota=r['cuota'] is None))
 (ROOT/'data/master.json').write_text(json.dumps(out,ensure_ascii=False,allow_nan=False));(ROOT/'data/cobertura.json').write_text(json.dumps(coverage,ensure_ascii=False))
 for name,rows in [('master',out),('cobertura',coverage),('faltantes',gaps),('ieps_semanal',weekly)]:
  with (ROOT/'data'/f'{name}.csv').open('w',newline='',encoding='utf-8-sig') as file:
   keys=list(dict.fromkeys(k for r in rows for k in r));writer=csv.DictWriter(file,fieldnames=keys);writer.writeheader();writer.writerows(rows)
 x=openpyxl.Workbook();x.remove(x.active)
 for title,rows in [('Datos diarios',out),('Cobertura',coverage),('Faltantes',gaps),('IEPS DOF',weekly)]:
  sh=x.create_sheet(title);keys=list(dict.fromkeys(k for r in rows for k in r));sh.append(keys)
  for r in rows:sh.append([r.get(k) for k in keys])
  sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
  for c in sh.columns:sh.column_dimensions[c[0].column_letter].width=22
 meta=x.create_sheet('Metodologia');meta.append(['Precios','Promedios nacionales reportados por estaciones, Cuadro 1.1 de archivo oficial CNE/CRE']);meta.append(['URL precios',URL_PRICE]);meta.append(['Cuotas','DOF: tablas publicadas directamente; vigencia inclusiva; sin interpolacion']);meta.append(['Categorias','Hasta 2019 los acuerdos dicen <92 / >=92 octanos; se conserva categoria_original. Desde 2020 dicen <91 / >=91.']);meta.append(['Derivada','Cuota aplicada = cuota publicada - estímulo complementario. Neto = precio - cuota publicada + estímulo complementario. Complementario ausente antes de 5 marzo 2022: no aplicable, cero para cálculo; después: pendiente. No representa precio libre de todos los impuestos']);meta.append(['Origen posterior','Desde 2024 cuotas del Excel inicial sin reverificacion; se conserva estado_cuota.']);meta.append(['SHA256 fuente precios',hashlib.sha256((ROOT/'raw/precios.xlsx').read_bytes()).hexdigest()]);x.save(ROOT/'historico_validado.xlsx')
 assert len({(r['fecha'],r['combustible']) for r in out})==len(out)
 assert all(r['neto'] is None or abs(r['precio']-r['cuota']-r['neto'])<1e-6 for r in out)
 print(json.dumps(coverage,ensure_ascii=False),flush=True)
if __name__=='__main__':build()
