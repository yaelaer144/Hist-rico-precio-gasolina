"""Actualiza cuotas semanales oficiales sin exigir precios CNE.
No extrapola acuerdos futuros y conserva precios previamente publicados.
"""
import csv,datetime as dt,json,os
from pathlib import Path
from zoneinfo import ZoneInfo
from cargar_dof import ROOT,week

def nuevas_fechas(base,hoy):
    ultimo=max(dt.date.fromisoformat(r['fecha']) for r in base)
    return [ultimo+dt.timedelta(days=i) for i in range(1,(hoy-ultimo).days+1)]

def integrar(base,acuerdos,hoy):
    # Validar acuerdos por fecha y combustible antes de insertar datos.
    existentes={(r['fecha'],r['combustible']):dict(r) for r in base}
    fechas=nuevas_fechas(base,hoy)
    for fecha in fechas:
        for fuel in ('regular','premium','diesel'):
            vigentes=[r for r in acuerdos if r['combustible']==fuel and r['inicio']<=fecha.isoformat()<=r['fin']]
            if not vigentes:continue
            valores={(r['cuota'],r.get('complementario'),r['cuota_completa']) for r in vigentes}
            if len(valores)!=1:raise ValueError('Acuerdos contradictorios: '+fecha.isoformat()+' '+fuel)
            r=vigentes[0]
            extra=r.get('complementario')
            # No presentar una cuota aplicada que no puede calcularse con la tabla oficial.
            cuota=round(r['cuota']-extra,6) if extra is not None else None
            registro=dict(fecha=fecha.isoformat(),combustible=fuel,precio=None,
                cuota_publicada=r['cuota'],complementario_calculo=extra,cuota=cuota,
                neto=None,estimulo_pct=r['estimulo_pct'],estimulo_monto=r['estimulo_monto'],
                complementario=extra,cuota_completa=r['cuota_completa'],
                publicacion=r['publicacion'],fuente='DOF; precio CNE pendiente',
                url_precio=None,url_dof=r['url_dof'],inicio_vigencia=r['inicio'],
                fin_vigencia=r['fin'],edicion=r['edicion'],categoria_original=r['categoria_original'],
                estado_cuota='DOF extraído y validado' if cuota is not None else 'DOF sin estímulo complementario validado',
                nota=r.get('nota'))
            existentes[(fecha.isoformat(),fuel)]=registro
    return sorted(existentes.values(),key=lambda r:(r['fecha'],r['combustible']))

def main():
    hoy=dt.datetime.now(ZoneInfo('America/Mexico_City')).date()
    base=json.loads((ROOT/'data/master.json').read_text())
    faltantes=nuevas_fechas(base,hoy)
    if not faltantes:
        print('DOF diario: histórico al día; ningún periodo nuevo.');return
    # Acuerdos por semana con un viernes de referencia (también revisa festivos).
    viernes=set()
    for dia in faltantes:
        viernes.add(dia+dt.timedelta(days=(4-dia.weekday())%7))
        viernes.add(dia-dt.timedelta(days=(dia.weekday()-4)%7))
    cache_path=ROOT/'data/ieps_semanal.json'
    cache=json.loads(cache_path.read_text()) if cache_path.exists() else []
    acuerdos=list(cache)
    # An already verified DOF agreement covers a date independently of price data.
    if all(any(r['combustible']==fuel and r['inicio']<=d.isoformat()<=r['fin']
               for r in acuerdos) for d in faltantes for fuel in ('regular','premium','diesel')):
        viernes.clear()
    for v in sorted(viernes):
        if v>hoy:continue
        # No invocar DOF si un acuerdo cacheado ya cubre todos los días
        # relevantes de esta semana para los tres combustibles.
        days=[d for d in faltantes if 0 <= (d-v).days <= 6]
        if days and all(any(r['combustible']==fuel and r['inicio']<=d.isoformat()<=r['fin']
                            for r in acuerdos) for d in days for fuel in ('regular','premium','diesel')):
            continue
        acuerdos.extend(week(v))
    updated=integrar(base,acuerdos,hoy)
    if len(updated)==len(base):
        print('DOF diario: acuerdos nuevos aún no accesibles; conservando histórico.');return
    target=ROOT/'data/master.json';tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(updated,ensure_ascii=False));os.replace(tmp,target)
    old=json.loads((ROOT/'data/ieps_semanal.json').read_text())
    unique={(r['inicio'],r['fin'],r['combustible']):r for r in old}
    unique.update({(r['inicio'],r['fin'],r['combustible']):r for r in acuerdos})
    (ROOT/'data/ieps_semanal.json').write_text(json.dumps(list(unique.values()),ensure_ascii=False))
    with (ROOT/'data/master.csv').open('w',newline='',encoding='utf-8-sig') as out:
        keys=list(dict.fromkeys(k for r in updated for k in r));writer=csv.DictWriter(out,fieldnames=keys)
        writer.writeheader();writer.writerows(updated)
    print('DOF diario: añadidos',len(updated)-len(base),'registros; corte',updated[-1]['fecha'])
if __name__=='__main__':main()
