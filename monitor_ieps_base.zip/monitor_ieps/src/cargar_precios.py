"""Descarga el archivo oficial descubierto en el indice CNE, no una serie reconstruida."""
from cargar_dof import fetch,ROOT,RAW
URL='https://www.cne.gob.mx/da/Precios_promedio_diarios_y_mensuales_en_estaciones_de_servicio.xlsx'
if __name__=='__main__':
 # Borrar cache solo de esta fuente para revisar la version oficial disponible.
 (RAW/'precios.xlsx').unlink(missing_ok=True)
 b=fetch(URL,'precios.xlsx')
 import openpyxl,io
 w=openpyxl.load_workbook(io.BytesIO(b),data_only=True)
 if 'Cuadro 1.1' not in w.sheetnames:raise ValueError('Cambio de estructura: revisar hoja de precios diarios')
 print('Excel oficial descargado:',len(b),'bytes')
