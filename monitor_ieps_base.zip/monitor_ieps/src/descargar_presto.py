"""Descarga dos exportaciones desde la interfaz pública Presto, sin endpoints inventados."""
import datetime as dt,json,re,unicodedata
from pathlib import Path
from zoneinfo import ZoneInfo
URL='http://presto.hacienda.gob.mx/EstoporLayout/Layout.jsp'
MONTHS={v:i+1 for i,v in enumerate('enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre'.split())}
def norm(value):return ' '.join(''.join(c for c in unicodedata.normalize('NFD',str(value).lower()) if not unicodedata.combining(c)).split())
def ultimo_cierre(texto):
 matches=re.findall(r'informacion\s+a\s+(\w+)\s+(?:de\s+)?(20\d{2})',norm(texto))
 dates={(int(y),MONTHS[m]) for m,y in matches if m in MONTHS}
 if len(dates)!=1:raise ValueError('No se identificó el corte oficial del portal; no asumir cierre anual')
 year,month=dates.pop();return year if month==12 else year-1,(year,month)

def frames(page):return [f for f in page.frames if not f.is_detached()]
def click_text(page,pattern,required=True):
 for frame in frames(page):
  matches=frame.get_by_text(re.compile(pattern,re.I))
  for i in range(matches.count()):
   loc=matches.nth(i)
   if loc.is_visible():loc.click(timeout=15000);page.wait_for_timeout(700);return
 if required:raise ValueError('No se encontró el control: '+pattern)

def selects(page):
 out=[]
 for frame in frames(page):
  locs=frame.locator('select')
  for i in range(locs.count()):
   loc=locs.nth(i)
   if loc.is_visible():out.append((loc,loc.evaluate('(s)=>Array.from(s.options).map(o=>({text:o.textContent,value:o.value}))')))
 return out

def select_text(page,label):
 found=[]
 for loc,options in selects(page):
  choices=[o for o in options if norm(o['text'])==norm(label)]
  if len(choices)==1:found.append((loc,choices[0]))
 if len(found)!=1:raise ValueError('Selector inexistente o ambiguo: '+label)
 loc,opt=found[0];loc.select_option(value=opt['value']);page.wait_for_timeout(500)
 return loc

def descargar(destino):
 from playwright.sync_api import sync_playwright
 destino=Path(destino);destino.mkdir(parents=True,exist_ok=True)
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True);context=browser.new_context(accept_downloads=True);page=context.new_page();page.set_default_timeout(20000)
  try:
   response=page.goto(URL,wait_until='domcontentloaded',timeout=60000)
   if response and response.status>=400:raise ValueError(f'Presto respondió HTTP {response.status}; base conservada')
   page.wait_for_timeout(1000)
   initial=' '.join(f.locator('body').inner_text() for f in frames(page))
   last,cut=ultimo_cierre(initial)
   if last<2017:raise ValueError('Corte no compatible con histórico desde 2017')
   click_text(page,r'^Reportes$',required=False)
   for label in [r'^Ingreso,?\s*gasto y financiamiento del sector p[uú]blico$',r'^Ingresos presupuestarios$',r'^Ingresos presupuestarios del sector p[uú]blico$']:click_text(page,label)
   select_text(page,'Pesos corrientes multianual')
   select_text(page,'Anual')
   year_controls=[]
   for loc,options in selects(page):
    vals={norm(o['text']):o['value'] for o in options}
    if '2017' in vals and str(last) in vals and sum(bool(re.fullmatch(r'20\d{2}',x)) for x in vals)>=3:year_controls.append((loc,vals))
   if len(year_controls)!=2:raise ValueError('No se identificaron inequívocamente los selectores De/A')
   year_controls[0][0].select_option(value=year_controls[0][1]['2017']);page.wait_for_timeout(300)
   # Releer los controles tras el cambio de fecha inicial.
   year_controls=[]
   for loc,options in selects(page):
    vals={norm(o['text']):o['value'] for o in options}
    if '2017' in vals and str(last) in vals and sum(bool(re.fullmatch(r'20\d{2}',x)) for x in vals)>=3:year_controls.append((loc,vals))
   if len(year_controls)!=2:raise ValueError('Cambió el selector de fechas')
   year_controls[1][0].select_option(value=year_controls[1][1][str(last)])
   for unit,name in [('Millones de pesos','montos.xls'),('Porcentajes del PIB','pib.xls')]:
    select_text(page,unit)
    selected=[norm(loc.evaluate('(s)=>s.options[s.selectedIndex].textContent')) for loc,_ in selects(page)]
    for value in ['Anual','Pesos corrientes multianual',unit,'2017',str(last)]:
     if norm(value) not in selected:raise ValueError('No se confirmó el filtro '+value)
    with page.expect_download(timeout=60000) as info:click_text(page,r'^Consultar\s*(?:y|&)\s*descargar$')
    download=info.value
    if download.failure():raise ValueError('Falló la exportación '+unit)
    download.save_as(str(destino/name))
   meta=dict(fuente=URL,consulta=dt.datetime.now(ZoneInfo('America/Mexico_City')).isoformat(),periodicidad='Anual',cuadro='Pesos corrientes multianual',desde=2017,hasta=last,corte_oficial=dict(ano=cut[0],mes=cut[1]),unidades=['Millones de pesos','Porcentajes del PIB'])
   (destino/'consulta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));return meta
  except Exception:
   page.screenshot(path=str(destino/'error.png'),full_page=True)
   (destino/'error.html').write_text(page.content())
   raise
  finally:context.close();browser.close()
