"""Cola persistente: periodos fijos y reintentos hasta un mes calendario."""
import calendar, datetime as dt

def mes_despues(fecha):
 y=fecha.year+(fecha.month==12);m=fecha.month%12+1
 return dt.date(y,m,min(fecha.day,calendar.monthrange(y,m)[1]))

def inicial():
 return {'version':1,'ultima_actualizacion_datos':'2026-10-09','origen_fecha':'carga inicial','tareas':{}}

def agregar(estado,tipo,fecha,parametro=None):
 referencia=parametro or (str(fecha.year) if tipo=='renuncias' else fecha.isoformat())
 periodo=(dt.date.fromisoformat(referencia).replace(day=1)-dt.timedelta(days=1)).strftime('%Y-%m') if tipo=='mensual' else referencia if tipo=='renuncias' else fecha.strftime('%Y-%m')
 clave=tipo+':'+periodo
 if clave not in estado['tareas']:
  estado['tareas'][clave]={'tipo':tipo,'periodo':periodo,'referencia':referencia,'inicio':fecha.isoformat(),'limite':mes_despues(fecha).isoformat(),'estado':'pendiente','intentos':0}
 return estado['tareas'][clave]

def planificar(estado,hoy,modo='programado',parametro=None):
 if modo=='programado':
  # Desde el día 10, recuperar el mes previo si la tarea no se creó
  # (por ejemplo, si Actions estuvo inactivo ese día).
  if hoy.day>=10:
   agregar(estado,'mensual',hoy,hoy.replace(day=10).isoformat())
  # Revisión diaria de atrasos PRESTO. El corte mensual se agenda al cierre;
  # la recuperación histórica debe continuar incluso fuera del último día.
  if hoy.day==calendar.monthrange(hoy.year,hoy.month)[1]:
   agregar(estado,'recaudacion',hoy)
  if hoy.month==7 and hoy.day==1:agregar(estado,'renuncias',hoy)
 elif modo!='publicar':
  tarea=agregar(estado,modo,hoy,parametro)
  # Una ejecución manual permite volver a consultar una tarea agotada o exitosa.
  if tarea['estado']!='pendiente':
   tarea.update(estado='pendiente',inicio=hoy.isoformat(),limite=mes_despues(hoy).isoformat())
   tarea.pop('ultimo_intento',None)
  tarea.pop('ultimo_intento',None)
 pendientes=[]
 for tarea in estado['tareas'].values():
  if tarea['estado']!='pendiente':continue
  if hoy>=dt.date.fromisoformat(tarea['limite']):tarea['estado']='agotado';continue
  if tarea.get('ultimo_intento','')[:10]!=hoy.isoformat():pendientes.append(tarea)
 return pendientes if modo!='publicar' else []

def registrar(estado,tarea,ahora,error=None):
 tarea['intentos']+=1;tarea['ultimo_intento']=ahora.isoformat()
 if error:
  tarea['error']=str(error)[:1500];tarea['estado']='pendiente'
 else:
  tarea['estado']='completado';tarea['ultimo_exito']=ahora.isoformat();tarea.pop('error',None)
  estado['ultima_actualizacion_datos']=ahora.isoformat();estado['origen_fecha']='consulta automática validada'
