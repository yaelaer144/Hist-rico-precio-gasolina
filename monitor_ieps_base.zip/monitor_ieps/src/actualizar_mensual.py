"""Consulta mensual oficial; no cambia la base si la cobertura es incompleta."""
import argparse,csv,datetime as dt,io,json,math,os,urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import openpyxl
from cargar_dof import ROOT,week
URL='https://www.cne.gob.mx/da/Precios_promedio_diarios_y_mensuales_en_estaciones_de_servicio.xlsx'
def periodo(fecha):
 fin=fecha.replace(day=1)-dt.timedelta(days=1)
 return fin.replace(day=1),fin

def construir(precios,acuerdos,inicio,fin):
 resultado=[];dia=inicio
 while dia<=fin:
  for fuel in ['regular','premium','diesel']:
   precio=precios.get((dia.isoformat(),fuel))
   candidates=[r for r in acuerdos if r['combustible']==fuel and r['inicio']<=dia.isoformat()<=r['fin']]
   if precio is None or not math.isfinite(precio) or precio<=0 or not candidates:raise ValueError(f'Falta precio o acuerdo: {dia} {fuel}')
   signatures={(r['cuota'],r['complementario'],r['cuota_completa']) for r in candidates}
   if len(signatures)!=1:raise ValueError(f'Acuerdos contradictorios: {dia} {fuel}')
   r=candidates[-1];extra=r['complementario']
   if extra is None and dia>=dt.date(2022,3,5):raise ValueError(f'Falta tabla de estímulo complementario: {dia} {fuel}')
   extra=extra or 0
   if not all(math.isfinite(r[k]) for k in ['cuota','cuota_completa','estimulo_pct','estimulo_monto']) or not math.isfinite(extra) or extra<0:raise ValueError('Valor fiscal inválido')
   cuota=round(r['cuota']-extra,6)
   resultado.append(dict(fecha=dia.isoformat(),combustible=fuel,precio=precio,cuota_publicada=r['cuota'],complementario_calculo=extra,cuota=cuota,neto=round(precio-cuota,6),estimulo_pct=r['estimulo_pct'],estimulo_monto=r['estimulo_monto'],complementario=r['complementario'],cuota_completa=r['cuota_completa'],publicacion=r['publicacion'],fuente='CNE/CRE y DOF',url_precio=URL,url_dof=r['url_dof'],inicio_vigencia=r['inicio'],fin_vigencia=r['fin'],edicion=r['edicion'],categoria_original=r['categoria_original'],estado_cuota='DOF extraído y validado',nota=r.get('nota')))
  dia+=dt.timedelta(days=1)
 return resultado

def main():
 p=argparse.ArgumentParser();p.add_argument('--fecha',default=dt.date.today().isoformat());p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 inicio,fin=periodo(dt.date.fromisoformat(a.fecha))
 request=urllib.request.Request(URL,headers={'User-Agent':'MonitorIEPS/1.0'})
 b=urllib.request.urlopen(request,timeout=60).read()
 libro=openpyxl.load_workbook(io.BytesIO(b),read_only=True,data_only=True)
 precios={}
 for row in libro['Cuadro 1.1'].iter_rows(values_only=True):
  try:
   day=row[0].date() if isinstance(row[0],dt.datetime) else row[0] if isinstance(row[0],dt.date) else dt.datetime.strptime(str(row[0]).strip(),'%d/%m/%Y').date()
   if inicio<=day<=fin:
    for fuel,value in zip(['regular','premium','diesel'],row[1:4]):precios[(day.isoformat(),fuel)]=float(value)
  except (ValueError,TypeError):continue
 libro.close()
 viernes=[];day=inicio-dt.timedelta(days=10)
 while day<=fin:
  if day.weekday()==4:viernes.append(day)
  day+=dt.timedelta(days=1)
 with ThreadPoolExecutor(max_workers=4) as pool:acuerdos=[r for result in pool.map(week,viernes) for r in result]
 nuevos=construir(precios,acuerdos,inicio,fin)
 base=json.loads((ROOT/'data/master.json').read_text());merged={(r['fecha'],r['combustible']):r for r in base}
 merged.update({(r['fecha'],r['combustible']):r for r in nuevos});rows=sorted(merged.values(),key=lambda r:(r['fecha'],r['combustible']))
 report=dict(consulta=dt.datetime.now(dt.timezone.utc).isoformat(),inicio=inicio.isoformat(),fin=fin.isoformat(),filas_actualizadas=len(nuevos),estado='Cobertura diaria completa; tres combustibles',fuente_precio=URL)
 if a.dry_run:print(json.dumps(report,ensure_ascii=False));return
 # Toda validación ocurre antes de escribir la base. Reemplazo atómico del JSON principal.
 target=ROOT/'data/master.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(rows,ensure_ascii=False));os.replace(tmp,target)
 old=json.loads((ROOT/'data/ieps_semanal.json').read_text());weekly={(r['inicio'],r['fin'],r['combustible']):r for r in old};weekly.update({(r['inicio'],r['fin'],r['combustible']):r for r in acuerdos});(ROOT/'data/ieps_semanal.json').write_text(json.dumps(list(weekly.values()),ensure_ascii=False))
 (ROOT/'raw/precios.xlsx').write_bytes(b)
 (ROOT/'data/actualizacion_mensual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 with (ROOT/'data/master.csv').open('w',newline='',encoding='utf-8-sig') as f:
  keys=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
