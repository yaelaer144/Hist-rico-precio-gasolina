"""Consulta mensual oficial; no cambia la base si la cobertura es incompleta."""
import argparse,csv,datetime as dt,io,json,math,os,urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import openpyxl
from cargar_dof import ROOT,week
from urllib.parse import quote

MESES = (
 'Enero','Febrero','Marzo','Abril',
 'Mayo','Junio','Julio','Agosto',
 'Septiembre','Octubre','Noviembre','Diciembre'
)

def url_cne(inicio):
 mes = MESES[inicio.month-1]
 carpeta = quote('DATOS ABIERTOS (GASOLINAS Y DIÉSEL)')
 nombre = (
  'Precios_promedio_diarios_y_mensuales_'
  'en_estaciones_de_servicio_'
  f'{mes.lower()}_{inicio.year}.xlsx'
 )
 return (
  f'https://www.cne.gob.mx/da/CNE/{carpeta}/'
  f'{inicio.year}/{mes}/{nombre}'
 )

URL = None
def parsear_fecha(valor):
 if isinstance(valor,str):
  texto=valor.strip().split(' ')[0]
  for formato in ('%Y-%m-%d','%d/%m/%Y','%d-%m-%Y'):
   try:
    return dt.datetime.strptime(texto,formato).date()
   except ValueError:
    pass
 raise ValueError(f'Fecha CNE no reconocida: {valor!r}')

def periodo(fecha):
 fin=fecha.replace(day=1)-dt.timedelta(days=1)
 return fin.replace(day=1),fin

def construir(precios,acuerdos,inicio,fin):
 resultado=[];dia=inicio
 while dia<=fin:
  for fuel in ['regular','premium','diesel']:
   precio=precios.get((dia.isoformat(),fuel))
   candidates=[r for r in acuerdos if r['combustible']==fuel and r['inicio']<=dia.isoformat()<=r['fin']]
   if precio is None or not math.isfinite(precio) or precio<=0 or not candidates:raise ValueError(f'Falta precio o acuerdo: {dia} {fuel}')
   signatures={(r['cuota'],r['complementario'],r['cuota_completa']) for r in candidates}
   if len(signatures)!=1:raise ValueError(f'Acuerdos contradictorios: {dia} {fuel}')
   r=candidates[-1];extra=r['complementario']
   if extra is None and dia>=dt.date(2022,3,5):raise ValueError(f'Falta tabla de estímulo complementario: {dia} {fuel}')
   extra=extra or 0
   if not all(math.isfinite(r[k]) for k in ['cuota','cuota_completa','estimulo_pct','estimulo_monto']) or not math.isfinite(extra) or extra<0:raise ValueError('Valor fiscal inválido')
   cuota=round(r['cuota']-extra,6)
   resultado.append(dict(fecha=dia.isoformat(),combustible=fuel,precio=precio,cuota_publicada=r['cuota'],complementario_calculo=extra,cuota=cuota,neto=round(precio-cuota,6),estimulo_pct=r['estimulo_pct'],estimulo_monto=r['estimulo_monto'],complementario=r['complementario'],cuota_completa=r['cuota_completa'],publicacion=r['publicacion'],fuente='CNE/CRE y DOF',url_precio=URL,url_dof=r['url_dof'],inicio_vigencia=r['inicio'],fin_vigencia=r['fin'],edicion=r['edicion'],categoria_original=r['categoria_original'],estado_cuota='DOF extraído y validado',nota=r.get('nota')))
  dia+=dt.timedelta(days=1)
 return resultado

def main():
 p=argparse.ArgumentParser();p.add_argument('--fecha',default=dt.date.today().isoformat());p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 inicio,fin=periodo(dt.date.fromisoformat(a.fecha))
 global URL
 URL=url_cne(inicio)
 print("CNE: descargando",URL,flush=True)
 request=urllib.request.Request(URL,headers={'User-Agent':'MonitorIEPS/1.0'})
 b=urllib.request.urlopen(request,timeout=60).read()
 libro=openpyxl.load_workbook(io.BytesIO(b),read_only=True,data_only=True)
 precios={}
 for row in libro['Cuadro 1.1'].iter_rows(values_only=True):
  try:
   day=row[0].date() if isinstance(row[0],dt.datetime) else row[0] if isinstance(row[0],dt.date) else parsear_fecha(row[0])
   if inicio<=day<=fin:
    for fuel,value in zip(['regular','premium','diesel'],row[1:4]):precios[(day.isoformat(),fuel)]=float(value)
  except (ValueError,TypeError):continue
 libro.close()
 print(
  f'CNE: {len(precios)} precios encontrados '
  f'para {inicio} a {fin}',
  flush=True
 )
 viernes=[];day=inicio-dt.timedelta(days=10)
 while day<=fin:
  if day.weekday()==4:viernes.append(day)
  day+=dt.timedelta(days=1)
 with ThreadPoolExecutor(max_workers=4) as pool:acuerdos=[r for result in pool.map(week,viernes) for r in result]
 nuevos=construir(precios,acuerdos,inicio,fin)
 base=json.loads((ROOT/'data/master.json').read_text());merged={(r['fecha'],r['combustible']):r for r in base}
 merged.update({(r['fecha'],r['combustible']):r for r in nuevos});rows=sorted(merged.values(),key=lambda r:(r['fecha'],r['combustible']))
 report=dict(consulta=dt.datetime.now(dt.timezone.utc).isoformat(),inicio=inicio.isoformat(),fin=fin.isoformat(),filas_actualizadas=len(nuevos),estado='Cobertura diaria completa; tres combustibles',fuente_precio=URL)
 if a.dry_run:print(json.dumps(report,ensure_ascii=False));return
 # Toda validación ocurre antes de escribir la base. Reemplazo atómico del JSON principal.
 target=ROOT/'data/master.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(rows,ensure_ascii=False));os.replace(tmp,target)
 old=json.loads((ROOT/'data/ieps_semanal.json').read_text());weekly={(r['inicio'],r['fin'],r['combustible']):r for r in old};weekly.update({(r['inicio'],r['fin'],r['combustible']):r for r in acuerdos});(ROOT/'data/ieps_semanal.json').write_text(json.dumps(list(weekly.values()),ensure_ascii=False))
 (ROOT/'raw/precios.xlsx').write_bytes(b)
 (ROOT/'data/actualizacion_mensual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 with (ROOT/'data/master.csv').open('w',newline='',encoding='utf-8-sig') as f:
  keys=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)
 print(json.dumps(report,ensure_ascii=False))



# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()


# Actualización automática de precios CNE.
from urllib.parse import quote
import re
import time

MESES_CNE = (
    "Enero", "Febrero", "Marzo", "Abril",
    "Mayo", "Junio", "Julio", "Agosto",
    "Septiembre", "Octubre", "Noviembre", "Diciembre"
)

def url_mensual_cne(inicio):
    mes = MESES_CNE[inicio.month - 1]
    carpeta = quote(
        "DATOS ABIERTOS (GASOLINAS Y DIÉSEL)", safe=""
    )
    nombre = (
        "Precios_promedio_diarios_y_mensuales_"
        "en_estaciones_de_servicio_"
        f"{mes.lower()}_{inicio.year}.xlsx"
    )
    return (
        f"https://www.cne.gob.mx/da/CNE/{carpeta}/"
        f"{inicio.year}/{mes}/{nombre}"
    )

def descargar_excel_cne(url):
    for intento in range(1, 4):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/vnd.openxmlformats-"
                              "officedocument.spreadsheetml.sheet,*/*",
                    "Cache-Control": "no-cache"
                }
            )
            with urllib.request.urlopen(req, timeout=90) as resp:
                contenido = resp.read()
                print(
                    "CNE HTTP:", resp.status,
                    "bytes:", len(contenido),
                    "URL:", resp.url,
                    flush=True
                )
            if not contenido.startswith(b"PK"):
                raise ValueError("La respuesta no es un Excel XLSX")
            return contenido
        except Exception as exc:
            print(
                f"CNE intento {intento}/3: {exc}",
                flush=True
            )
            if intento == 3:
                raise
            time.sleep(3 * intento)

def leer_excel_cne(contenido, inicio, fin):
    libro = openpyxl.load_workbook(
        io.BytesIO(contenido),
        read_only=True,
        data_only=True
    )
    try:
        if "Cuadro 1.1" not in libro.sheetnames:
            raise ValueError(
                f"No existe Cuadro 1.1: {libro.sheetnames}"
            )

        hoja = libro["Cuadro 1.1"]
        precios = {}
        ultima_fecha = None

        for fila in hoja.iter_rows(
            min_row=5, max_col=4, values_only=True
        ):
            valor = fila[0]
            try:
                if isinstance(valor, dt.datetime):
                    dia = valor.date()
                elif isinstance(valor, dt.date):
                    dia = valor
                else:
                    cadena = str(valor).strip().split(" ")[0]
                    dia = None
                    for formato in (
                        "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"
                    ):
                        try:
                            dia = dt.datetime.strptime(
                                cadena, formato
                            ).date()
                            break
                        except ValueError:
                            continue

                    if dia is None:
                        continue

                ultima_fecha = (
                    max(ultima_fecha, dia)
                    if ultima_fecha else dia
                )

                if not inicio <= dia <= fin:
                    continue

                for combustible, valor_precio in zip(
                    ("regular", "premium", "diesel"),
                    fila[1:4]
                ):
                    precio = float(valor_precio)

                    if not math.isfinite(precio) or not 5 <= precio <= 100:
                        raise ValueError(
                            f"Precio inválido: {dia} {combustible}"
                        )

                    precios[(dia.isoformat(), combustible)] = precio

            except (TypeError, ValueError) as exc:
                if (
                    isinstance(valor, (dt.date, dt.datetime))
                    or re.match(r"^\d{4}-\d\d-\d\d$", str(valor))
                ):
                    raise ValueError(
                        f"Fila CNE inválida: {valor}: {exc}"
                    ) from exc

        esperados = ((fin - inicio).days + 1) * 3

        print(
            f"CNE última fecha del Excel: {ultima_fecha}",
            f"Precios: {len(precios)}/{esperados}",
            flush=True
        )

        if len(precios) != esperados:
            raise ValueError(
                f"CNE incompleta para {inicio} a {fin}: "
                f"{len(precios)}/{esperados}"
            )

        return precios
    finally:
        libro.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fecha", default=dt.date.today().isoformat()
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    inicio, fin = periodo(
        dt.date.fromisoformat(args.fecha)
    )

    url = url_mensual_cne(inicio)
    print("CNE URL mensual:", url, flush=True)

    contenido = descargar_excel_cne(url)
    precios = leer_excel_cne(contenido, inicio, fin)

    archivo = ROOT / "data/master.json"
    base = json.loads(
        archivo.read_text(encoding="utf-8")
    )

    registros = {
        (r["fecha"], r["combustible"]): r
        for r in base
    }

    faltantes = set(precios) - set(registros)

    if faltantes:
        raise ValueError(
            "Faltan registros fiscales en la base: "
            + str(sorted(faltantes)[:5])
        )

    for clave, precio in precios.items():
        fila = registros[clave]
        fila["precio"] = precio
        fila["url_precio"] = url
        fila["fuente"] = (
            "CNE (precio); datos fiscales conservados"
        )

        cuota = fila.get("cuota")
        fila["neto"] = (
            round(precio - float(cuota), 6)
            if cuota is not None else None
        )

    reporte = {
        "periodo": inicio.strftime("%Y-%m"),
        "inicio": inicio.isoformat(),
        "fin": fin.isoformat(),
        "filas_actualizadas": len(precios),
        "fuente_precio": url,
        "estado": "CNE: cobertura diaria completa"
    }

    if args.dry_run:
        print(json.dumps(reporte, ensure_ascii=False, indent=2))
        return

    filas = sorted(
        registros.values(),
        key=lambda r: (r["fecha"], r["combustible"])
    )

    temporal = archivo.with_suffix(".tmp")
    temporal.write_text(
        json.dumps(filas, ensure_ascii=False),
        encoding="utf-8"
    )
    os.replace(temporal, archivo)

    with (ROOT / "data/master.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as salida:
        columnas = list(
            dict.fromkeys(c for f in filas for c in f)
        )
        escritor = csv.DictWriter(
            salida, fieldnames=columnas
        )
        escritor.writeheader()
        escritor.writerows(filas)

    (ROOT / "data/actualizacion_mensual.json").write_text(
        json.dumps(reporte, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    (ROOT / "raw").mkdir(exist_ok=True)
    (ROOT / "raw/precios.xlsx").write_bytes(contenido)

    print(
        "CNE: PRECIOS INCORPORADOS",
        len(precios), "hasta", fin,
        flush=True
    )

if __name__ == "__main__":
    main()
