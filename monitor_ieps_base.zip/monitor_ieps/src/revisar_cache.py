import pathlib,re,json,datetime as dt,sys
from lxml import html
from cargar_dof import norm,parse,RAW,ROOT,fetch
references={}
for p in sorted(RAW.glob('index-*.html')):
 day=p.name[6:16];edition=p.stem[-3:]
 for a in html.fromstring(p.read_bytes()).xpath('//a[@href]'):
  text=norm(' '.join(a.itertext()));href=a.get('href')
  if 'cuotas disminuidas' in text and 'porcentajes' in text and 'nota_detalle' in href:
   m=re.search(r'codigo=(\d+)',href)
   if m:references.setdefault(m.group(1),[]).append((day,edition))
additional=ROOT/'data/referencias_adicionales.json'
if additional.exists():
 for item in json.loads(additional.read_text()):references.setdefault(item['codigo'],[]).append((item['publicacion'],item['edicion']))
rows=[];errors=[]
for code,candidates in references.items():
 day,edition=candidates[0]
 p=RAW/(code+'.html')
 if not p.exists():
  try:fetch('https://dof.gob.mx/nota_detalle_popup.php?codigo='+code,code+'.html')
  except Exception as e:errors.append(dict(codigo=code,error=str(e)));continue
 try:
  result=parse(p.read_bytes(),'https://dof.gob.mx/nota_detalle_popup.php?codigo='+code,day,edition)
  start=dt.date.fromisoformat(result[0]['inicio'])
  valid=[(d,e) for d,e in candidates if 0<=(start-dt.date.fromisoformat(d)).days<=7]
  if valid:
   day,edition=min(valid,key=lambda pair:abs((start-dt.date.fromisoformat(pair[0])).days-1))
   for r in result:r['publicacion']=day;r['edicion']=edition
  else:raise ValueError('Publicacion del indice incompatible con la vigencia; revisar fuente')
  rows+=result
 except Exception as e:errors.append(dict(codigo=code,fecha=day,error=str(e)))
(ROOT/'data/ieps_semanal.json').write_text(json.dumps(sorted(rows,key=lambda r:(r['inicio'],r['combustible'])),ensure_ascii=False));(ROOT/'data/errores_parseo.json').write_text(json.dumps(errors,ensure_ascii=False));print(len(rows)//3,'acuerdos reprocesados;',len(errors),'errores')
