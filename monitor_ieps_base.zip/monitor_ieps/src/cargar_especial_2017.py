"""Decretos iniciales verificados; excepcion a la serie semanal iniciada en febrero."""
import datetime as dt,json
from cargar_dof import fetch,parse,ROOT
SOURCES=[('5467667','2017-01-01','2017-02-03','2016-12-27','MAT'),('5470869','2017-02-04','2017-02-10','2017-02-03','MAT'),('5471583','2017-02-11','2017-02-17','2017-02-10','VES'),('5472383','2017-02-18','2017-02-24','2017-02-17','VES')]
if __name__=='__main__':
 rows=[]
 for code,start,end,publication,edition in SOURCES:
  url='https://dof.gob.mx/nota_detalle_popup.php?codigo='+code
  result=parse(fetch(url,code+'.html'),url,publication,edition,(dt.date.fromisoformat(start),dt.date.fromisoformat(end)))
  for r in result:r['nota']='Decretos y reformas iniciales; convencion diaria: cambio a las 04:00 en febrero, sin ponderacion intradia.';r['acuerdo']='Decreto '+code
  rows+=result
 (ROOT/'data/ieps_especial_2017.json').write_text(json.dumps(rows,ensure_ascii=False));print('Decretos iniciales extraidos y validados')
