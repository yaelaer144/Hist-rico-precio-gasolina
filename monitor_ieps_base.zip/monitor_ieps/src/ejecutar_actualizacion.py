"""Punto de entrada de Actions; las fallas conservan datos y publican avisos con reintentos."""
import datetime as dt,json,os,re,subprocess,sys,shutil,tempfile
from calendario_actualizacion import inicial,planificar,registrar
from estado_dashboard import aplicar
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]

def seleccionar(evento,calendario,consulta):
 if evento=='schedule':
  return {'0 15 * * *':'programado','0 3 * * 6':'programado','0 15 10 * *':'mensual','0 15 1 7 *':'renuncias','0 15 10 1,3,5,7,9,11 *':'recaudacion'}[calendario]
 if evento=='push':return 'publicar'
 if evento=='workflow_dispatch' and consulta in ('publicar','programado','mensual','renuncias','recaudacion'):return consulta
 raise ValueError('Evento o consulta no reconocido')

def run(script,*args):
 subprocess.run([sys.executable,str(ROOT/'src'/script),*args],cwd=ROOT,check=True,env={**os.environ,'IEPS_SOLO_DASHBOARD':'1'})

def main():
 mode=seleccionar(os.environ.get('EVENTO','workflow_dispatch'),os.environ.get('CALENDARIO',''),os.environ.get('CONSULTA','publicar'))
 now=dt.datetime.now(ZoneInfo('America/Mexico_City'));report={'consulta':mode,'ejecucion':now.isoformat()}
 state_path=ROOT/'data/estado_actualizacion.json'
 estado=json.loads(state_path.read_text()) if state_path.exists() else inicial()
 parametro=None
 if mode=='mensual':
  parametro=os.environ.get('FECHA_REFERENCIA','').strip() or now.date().isoformat()
  dt.date.fromisoformat(parametro)
 elif mode=='renuncias':
  parametro=os.environ.get('ANO_EDICION','').strip() or str(now.year)
  if not re.fullmatch(r'20\d{2}',parametro) or not 2017<=int(parametro)<=now.year:raise ValueError('Edición inválida o futura')
 anterior=json.dumps(estado,sort_keys=True)
 tareas=planificar(estado,now.date(),mode,parametro)
 if os.environ.get('SOLO_PLAN')=='1':
  output=os.environ.get('GITHUB_OUTPUT')
  if output:
   with open(output,'a') as f:f.write('presto='+str(any(t['tipo']=='recaudacion' for t in tareas)).lower()+'\n')
  print(json.dumps(tareas,ensure_ascii=False));return
 if mode=='programado' and not tareas and anterior==json.dumps(estado,sort_keys=True):
  print('Sin consultas periódicas; revisando DOF diario.')
 for tarea in tareas:
  with tempfile.TemporaryDirectory() as tmp:
   copia=Path(tmp)/'data';shutil.copytree(ROOT/'data',copia)
   try:
    if tarea['tipo']=='mensual':run('actualizar_mensual.py','--fecha',tarea['referencia'])
    elif tarea['tipo']=='renuncias':run('actualizar_renuncias.py','--ano',tarea['referencia'])
    else:run('recaudacion_mensual.py')
   except (subprocess.CalledProcessError,OSError,ValueError) as exc:
    shutil.rmtree(ROOT/'data');shutil.copytree(copia,ROOT/'data')
    registrar(estado,tarea,now,error=exc)
    print('Consulta pendiente: '+tarea['tipo']+' '+tarea['periodo'])
   else:registrar(estado,tarea,now)
 # Las cuotas DOF se consultan diariamente, independientemente del cierre CNE.
 if mode in ('programado','mensual'):
  try:run('actualizar_dof_diario.py')
  except (subprocess.CalledProcessError,OSError,ValueError) as exc:
   print('DOF diario pendiente; se conservan datos anteriores:',str(exc))
 report['tareas']=tareas
 state_path.write_text(json.dumps(estado,ensure_ascii=False,indent=2))
 run('generar_index.py');run('agregar_recaudacion.py');run('agregar_recaudacion_mensual.py');run('ajustes_graficas.py')
 # Verificar que las dos bases presentes en HTML son las de este checkout.
 h=(ROOT/'index.html').read_text()
 master=json.loads((ROOT/'data/master.json').read_text());annual=json.loads((ROOT/'data/renuncias_recaudatorias.json').read_text())
 embedded=re.search(r'const embeddedData=(.*?);\nfunction load',h,re.S)
 fiscal=re.search(r'const renunciasData=(.*?);\nfunction renunciaChart',h,re.S)
 compact=re.search(r'const _compactData=(.*?);\nconst embeddedData=',h,re.S)
 if compact:
  bundle=json.loads(compact.group(1))
  actual=[{key:(bundle['d'][key][row[i]] if key in bundle['d'] else row[i]) for i,key in enumerate(bundle['k'])} for row in bundle['r']]
 elif embedded:
  actual=json.loads(embedded.group(1))
 else:raise ValueError('HTML no contiene el histórico vigente')
 if actual!=master:raise ValueError('HTML no corresponde al histórico vigente')
 if not fiscal or json.loads(fiscal.group(1))!=sorted(annual,key=lambda r:r['ano']):raise ValueError('HTML no corresponde a EF.DP.1 vigente')
 revenue=re.search(r'const annualData=(.*?);\nfunction niceAnnualScale',h,re.S)
 if not revenue or json.loads(revenue.group(1))!=json.loads((ROOT/'data/recaudacion_anual.json').read_text()):raise ValueError('HTML no corresponde a la recaudación vigente')
 aplicar(estado)
 if mode not in ('publicar','programado'):(ROOT/'data/ultima_actualizacion_github.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2))
 summary=os.environ.get('GITHUB_STEP_SUMMARY')
 if summary:
  with open(summary,'a',encoding='utf-8') as f:
   f.write('## Datos preparados y validados\n\n```json\n'+json.dumps(report,ensure_ascii=False,indent=2)+'\n```\n\nLa publicación se realiza en el trabajo publicar. Consulte su estado por separado.\n')
if __name__=='__main__':main()
