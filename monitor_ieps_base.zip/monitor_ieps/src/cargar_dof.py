"""Carga reproducible de acuerdos nacionales DOF. Guarda originales y rechaza tablas ambiguas."""
import urllib.request,urllib.parse,datetime as dt,pathlib,re,json,unicodedata,concurrent.futures,threading,time
from lxml import html
ROOT=pathlib.Path(__file__).resolve().parents[1];RAW=ROOT/'raw';RAW.mkdir(exist_ok=True);lock=threading.Lock();errors=[]
MONTHS={m:i+1 for i,m in enumerate('enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre'.split())}
def norm(t):return ' '.join(''.join(c for c in unicodedata.normalize('NFD',t.lower()) if not unicodedata.combining(c)).split())
def fetch(url,key):
 p=RAW/key
 if p.exists():return p.read_bytes()
 err=None
 for attempt in range(2):
  try:
   b=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MonitorIEPS/1.0 (consulta de datos publicos)'}),timeout=35).read()
   if len(b)<100:raise ValueError('Respuesta vacia')
   p.write_bytes(b);return b
  except Exception as e:err=e
 raise err

def period(text):
 t=norm(text)
 # Diferentes meses o anos; mismo mes; "1o.".
 patterns=[r'(?:periodo comprendido|periodo) (?:del|de) (\d+)(?:o\.)? de (\w+)(?: de (\d{4}))? al (\d+)(?:o\.)? (?:de )?(\w+) de (\d{4})',r'(?:periodo comprendido|periodo) (?:del|de) (\d+)(?:o\.)? al (\d+)(?:o\.)? (?:de )?(\w+) de (\d{4})']
 for n,p in enumerate(patterns):
  m=re.search(p,t)
  if not m:continue
  if n==0:
   d1,mo1,y1,d2,mo2,y2=m.groups();y2=int(y2);y1=int(y1) if y1 else y2-(MONTHS[mo1]>MONTHS[mo2]);a=dt.date(y1,MONTHS[mo1],int(d1));b=dt.date(y2,MONTHS[mo2],int(d2))
  else:
   d1,d2,mo,y=m.groups();a=dt.date(int(y),MONTHS[mo],int(d1));b=dt.date(int(y),MONTHS[mo],int(d2))
  if not 0<=(b-a).days<=31:raise ValueError('Vigencia no coherente')
  return a,b
 raise ValueError('No se pudo extraer vigencia')
def parse(b,url,publication,edition,explicit_period=None):
 tree=html.fromstring(b)
 for node in tree.xpath('//style|//script'):node.drop_tree()
 text=' '.join(tree.itertext());a,z=explicit_period or period(text);tables={};categories={}
 for tb in tree.xpath('//table'):
  rows=[]
  for tr in tb.xpath('./tr|./tbody/tr'):
   cells=[' '.join(c.itertext()) for c in tr.xpath('./td|./th')]
   if len(cells)==2:rows.append(cells)
  if len(rows)!=4:continue
  header=norm(' '.join(rows[0]));kind='complementario' if 'complementario' in header or ('cantidad' in header and 'litro' in header) else 'estimulo_pct' if 'porcentaje' in header else 'cuota' if 'cuota' in header else 'estimulo_monto' if 'monto' in header and 'estimulo' in header else None
  # El DOF puede separar Combustible/Cantidad por litro en otra tabla.
  if kind is None and header=='(pesos)':
   context=norm(' '.join(' '.join(e.itertext()) for e in list(tb.itersiblings(preceding=True))[:2]))
   if 'cantidad por litro' in context and 'estimulos complementarios' in context:kind='complementario'
  if kind is None:continue
  vals={}
  for label,value in rows[1:]:
   label=norm(label);fuel='regular' if 'menor' in label else 'premium' if 'mayor' in label else 'diesel' if 'diesel' in label else None
   if fuel is None:raise ValueError('Combustible inesperado')
   clean_value=re.sub(r'(?<=\d)\s*\.\s*(?=\d)', '.', value.replace(',',''))
   nums=re.findall(r'-?\d+(?:\.\d+)?',clean_value)
   if len(nums)!=1:raise ValueError('Valor ambiguo '+value)
   vals[fuel]=float(nums[0]);categories[fuel]=label
  if set(vals)!={'regular','premium','diesel'}:raise ValueError('Faltan combustibles')
  if kind in tables and tables[kind]!=vals:raise ValueError('Tablas contradictorias')
  tables[kind]=vals
 # Algunos documentos antiguos tienen filas fuera del elemento table.
 if 'cuota' not in tables:
  tail=norm(text).split('cuota disminuida (pesos/litro)')[-1]
  matches=re.findall(r'(gasolina menor[^$]+|gasolina mayor[^$]+|diesel)\s*\$\s*(\d+(?:\.\d+)?)',tail)
  if len(matches)==3:
   tables['cuota']={('regular' if 'menor' in label else 'premium' if 'mayor' in label else 'diesel'):float(value) for label,value in matches}
 if not all(k in tables for k in ['cuota','estimulo_pct','estimulo_monto']):raise ValueError('Faltan tablas requeridas')
 agreement=re.search(r'Acuerdo\s+(\d+/\d{4})',text,re.I)
 result=[]
 for fuel in ['regular','premium','diesel']:
  q=tables['cuota'][fuel];pct=tables['estimulo_pct'][fuel];amount=tables['estimulo_monto'][fuel];full=q+amount
  if min(q,amount)<0 or not 0<=pct<=100:raise ValueError('Rango fiscal invalido')
  warning='Inconsistencia publicada: porcentaje no coincide con monto/cuota. Se conservan los valores del DOF sin corregir.' if abs(full*pct/100-amount)>0.002 else None
  result.append(dict(inicio=a.isoformat(),fin=z.isoformat(),combustible=fuel,cuota=q,estimulo_pct=pct,estimulo_monto=amount,cuota_completa=round(full,6),nota=warning,complementario=tables.get('complementario',{}).get(fuel),categoria_original=categories[fuel],url_dof=url,publicacion=publication,edicion=edition,acuerdo=agreement.group(1) if agreement else None))
 return result

def index(day,edition):
 date=day.isoformat();url=f'https://dof.gob.mx/index.php?year={day.year}&month={day.month:02}&day={day.day:02}&edicion={edition}'
 b=fetch(url,f'index-{date}-{edition}.html');tree=html.fromstring(b);links={}
 for a in tree.xpath('//a[@href]'):
  t=norm(' '.join(a.itertext()));h=a.get('href')
  if 'cuotas disminuidas' in t and 'porcentajes' in t and 'combustibles' in t and 'nota_detalle' in h:
   m=re.search(r'codigo=(\d+)',h)
   if m:links[m.group(1)]=f'https://dof.gob.mx/nota_detalle_popup.php?codigo={m.group(1)}'
 out=[]
 for code,url in links.items():out+=parse(fetch(url,f'{code}.html'),url,date,edition)
 return out

def week(friday):
 out=[]
 try:
  # Primero viernes; si falta, ambas ediciones y dias cercanos por festivos.
  for shift in [0,-1,-2,-3,-4,1]:
   day=friday+dt.timedelta(days=shift)
   for edition in ['MAT','VES']:
    result=index(day,edition)
    # Validar que la vigencia corresponda a la semana objetivo.
    out += [r for r in result if dt.date.fromisoformat(r['inicio'])<=friday+dt.timedelta(days=7) and dt.date.fromisoformat(r['fin'])>=friday]
    if out:return out
  raise ValueError('No se encontro acuerdo en ventana de busqueda')
 except Exception as e:
  with lock:errors.append(dict(viernes=friday.isoformat(),error=str(e)))
  return out

def main():
 dates=[];d=dt.date(2017,2,24)
 while d<=dt.date(2023,12,29):dates.append(d);d+=dt.timedelta(days=7)
 rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  futures={pool.submit(week,d):d for d in dates}
  for n,f in enumerate(concurrent.futures.as_completed(futures),1):
   rows+=f.result()
   if n%10==0 or n==len(dates):
    (ROOT/'data/ieps_semanal.json').write_text(json.dumps(rows,ensure_ascii=False));(ROOT/'data/errores.json').write_text(json.dumps(errors,ensure_ascii=False));print(f'{n}/{len(dates)} semanas revisadas; {len(rows)//3} acuerdos; {len(errors)} pendientes',flush=True)
 # Deduplicar, pero nunca resolver silenciosamente contradicciones.
 unique={}
 for r in rows:
  key=(r['inicio'],r['fin'],r['combustible']);old=unique.get(key)
  if old and old['cuota']!=r['cuota']:raise ValueError('Acuerdos contradictorios '+str(key))
  unique[key]=r
 (ROOT/'data/ieps_semanal.json').write_text(json.dumps(sorted(unique.values(),key=lambda r:(r['inicio'],r['combustible'])),ensure_ascii=False))
if __name__=='__main__':main()
