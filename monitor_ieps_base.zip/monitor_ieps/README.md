# Monitor IEPS · Combustibles

Dashboard de precios nacionales diarios y cuotas IEPS de gasolina regular, premium y diésel desde 2017. Incluye recaudación anual y renuncias recaudatorias EF.DP.1 total. Abra `index.html` para verlo sin conexión.

Para subirlo y activar las consultas, lea **GUIA_GITHUB.md**. El archivo `.github/workflows/actualizar-dashboard.yml` debe quedar en la raíz del repositorio, junto con `index.html`, `src/`, `data/`, `raw/` y `requirements.txt`.

## Calendario de GitHub Actions

- Día 10 de cada mes, 09:00 de Ciudad de México (15:00 UTC): precios diarios CNE del mes anterior y acuerdos DOF que cubren todas sus fechas.
- 1 de julio de cada año, 09:00 de Ciudad de México: consulta la edición SHCP del año vigente, EF.DP.1 total y su porcentaje del PIB publicado en la misma tabla.
- Día 10 de enero, marzo, mayo, julio, septiembre y noviembre, 09:00 CDMX: recaudación anual, millones de pesos y porcentajes del PIB de SHCP/Presto. Se descargan conjuntamente, con periodicidad Anual y sólo años cerrados.
- Cada subida a `main`: regenera y publica con las bases existentes; no consulta fuentes.
- Botón `Run workflow`: permite publicar, consultar un mes o consultar una edición fiscal sin esperar al calendario.

Un error de consulta, validación o generación detiene el flujo antes de guardar datos y publicar. La versión anterior sigue disponible. Un error posterior al commit durante la publicación puede dejar datos nuevos en el repositorio y la página anterior; se debe volver a ejecutar `publicar`.

Estos archivos preparan la automatización, pero no activan por sí solos un repositorio remoto. Es necesario subirlos, configurar Pages y ejecutar una primera prueba. GitHub puede retrasar ejecuciones y desactiva calendarios de repositorios públicos tras 60 días sin actividad. No se garantiza que los portales oficiales permitan descargar desde todos los ejecutores. Si una publicación fiscal aún no existe el 1 de julio, se reporta como pendiente mediante la ejecución fallida; se puede reintentar manualmente.

## Bases y fuentes

- `data/master.json` y CSV: base diaria; `src/generar_index.py` la incorpora al dashboard. Fuente de precios: https://www.cne.gob.mx/da/Precios_promedio_diarios_y_mensuales_en_estaciones_de_servicio.xlsx, Cuadro 1.1. Los precios son promedios nacionales reportados por estaciones.
- Cuotas: tablas publicadas en DOF; vigencias inclusivas. Cada registro conserva URL, vigencia, publicación, edición y categoría original. La actualización mensual exige cobertura completa de los tres combustibles, sin interpolación.
- Cuota aplicada = cuota publicada − estímulo complementario. Precio menos cuota = precio − cuota publicada + estímulo complementario. Se permite una cuota aplicada negativa. Desde el 5 de marzo de 2022 un complementario ausente se considera pendiente, no cero.
- La cuota completa conserva cuota publicada + monto del estímulo ordinario, con el redondeo de la fuente. Se conservan advertencias publicadas sobre porcentajes y montos.
- `data/renuncias_recaudatorias.json`: EF.DP.1 total, 2017–2026. Estimaciones fiscales de SHCP, no costos efectivamente observados. Para 2023 se conserva la edición 2022. 2026: 28,711 millones de pesos y 0.0769% del PIB. Fuente: https://www.gob.mx/cms/uploads/attachment/file/1086727/DRR_2026.pdf
- `data/recaudacion_anual.json`: montos anuales 2017–2025 de la exportación Presto aportada el 9 de octubre de 2026. Porcentajes del PIB de la exportación previa, pendientes de cotejo con periodicidad anual. El calendario bimestral incorpora una descarga desde la interfaz Presto para ambas unidades; hasta su primera consulta exitosa se conserva esta base y la advertencia del porcentaje pendiente de cotejo anual.

## Alcance del histórico inicial

La extracción histórica original conserva precios oficiales y cuotas DOF 2017–2023; desde 2024 se mantiene la base inicial con su procedencia y estado de verificación. Cada consulta mensual exitosa sustituye solamente el mes consultado por cifras oficiales verificadas. No reverifica automáticamente todos los meses anteriores a ese mes.

Los documentos fiscales antiguos usan 92 octanos, los más recientes 91; se conserva la clasificación publicada. Los cambios de cuota a las 04:00 de febrero de 2017 se asignan al día de entrada en vigor sin ponderación intradía.

`historico_validado.xlsx` es una instantánea de auditoría inicial, no la salida de las consultas mensuales. Las descargas CSV y Excel dentro del dashboard usan los datos vigentes embebidos y permiten elegir el histórico completo o el periodo seleccionado. Las gráficas mantienen PNG, leyendas independientes, ejes separados, línea cero visible dentro de su escala y tooltip.

## Consulta de recaudación

`python src/actualizar_recaudacion.py` abre Presto con Playwright, confirma filtros, descarga las dos unidades y valida la fila IEPS gasolinas y diesel. Instalar el navegador con `python -m playwright install chromium` (en el ejecutor Ubuntu, el workflow utiliza `--with-deps`).

No se usa un porcentaje calculado a partir de otro PIB. El corte del portal determina el último año cerrado: si informa agosto de 2026, el límite es 2025; si informa diciembre de 2026, el límite es 2026. No se presenta el acumulado del año en curso como recaudación anual. Los formatos XML Spreadsheet, XLSX, XLS binario y tablas HTML se reconocen antes de leer la fila.

Si las fuentes no responden, faltan años, no se confirman los filtros o cambia la interfaz, se detiene sin guardar en GitHub ni publicar. El paso de diagnóstico puede guardar una captura en los artefactos de la ejecución. La navegación automática todavía requiere prueba real cuando Hacienda vuelva a estar accesible.

## Ejecución local

Python 3.12:

```sh
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Para regenerar sin consultar fuentes:

```sh
python src/ejecutar_actualizacion.py
```

Para consultar el mes anterior a una fecha (ejemplo: septiembre de 2026):

```sh
python src/actualizar_mensual.py --fecha 2026-10-10
```

Para consultar una edición fiscal:

```sh
python src/actualizar_renuncias.py --ano 2026
```

Ambos aceptan `--dry-run` para validar sin escribir. Después de una consulta exitosa, ejecutar `python src/ejecutar_actualizacion.py` regenera el dashboard. No ejecutar `construir_historico.py` para las actualizaciones: es la reconstrucción de la instantánea inicial con corte fijo.

Los originales recuperados se conservan en `raw/`. No se usa una caché de precios para simular una descarga nueva. EF.DP.1 se valida antes de reemplazar el registro del año; no suma desgloses a/b/c ni toma la columna del año siguiente.

## Verificación de esta entrega

Se verificaron cambios de año y febrero bisiesto, selección de eventos, cuota negativa, rechazo de falta de precio/complementario y extracción de la columna correcta de EF.DP.1. La regeneración completa se ejecutó y el HTML se comparó con las dos bases JSON. El lector de Presto se probó con el archivo real de montos y una tabla sintética de porcentajes; se comprobaron filtros anuales, años coincidentes, datos negativos y rechazo de acumulados parciales. La consulta directa de SHCP devolvió 403 y Presto devolvió 502 en este entorno; el funcionamiento desde GitHub queda pendiente de la primera ejecución real.

Los cron de ChatGPT creados antes de esta migración siguen activos hasta que se desactiven. Conviene hacerlo cuando el flujo de GitHub esté funcionando para evitar dos sistemas de actualización independientes.
