# Subir el monitor y activar GitHub Actions

## 1. Subir el proyecto desde Windows

Use GitHub Desktop para subir de una vez los archivos y la carpeta `.github`.

1. Descargue el ZIP y use **Extraer todo**. Dentro encontrará `monitor_ieps`, con el dashboard y todos los archivos.
2. Instale GitHub Desktop desde https://desktop.github.com/ e inicie sesión con su cuenta de GitHub.
3. En GitHub Desktop: **File → New repository**. Nombre: `monitor-ieps`. Seleccione una carpeta de destino y pulse **Create repository**.
4. Abra la carpeta recién creada. Copie **todo el contenido** de la carpeta extraída `monitor_ieps` dentro de ella. Incluya `.github`, `.gitignore` y `.gitattributes`. Si pregunta por README, use el del paquete. No copie una segunda carpeta `monitor_ieps` dentro del repositorio.
5. En GitHub Desktop, revise la lista **Changes**, escriba `Carga inicial del dashboard IEPS` y pulse **Commit to main**.
6. Pulse **Publish repository**. Si usará GitHub Free y desea una página accesible por enlace, el repositorio debe ser público: desmarque **Keep this code private**. Si tiene un plan compatible puede elegir privado. Revise la visibilidad antes de publicar.
7. Pulse **View on GitHub**. En la raíz deben verse `index.html`, `requirements.txt`, `src`, `data`, `raw`, `tests` y `.github`. Dentro de `.github/workflows` debe estar `actualizar-dashboard.yml`.

La primera ejecución podría fallar si Pages todavía no está configurado. Configure el siguiente paso y vuelva a ejecutarla.

Si ya tiene un repositorio, clone ese repositorio con Desktop, copie el contenido en su raíz y haga **Commit** y **Push origin**. El workflow escucha subidas a `main`; si su rama principal tiene otro nombre, adapte `branches: [main]` al nombre correcto antes de subirlo. Las consultas programadas usan la rama predeterminada.

No suba solamente el ZIP como un archivo dentro de GitHub: GitHub no lo descomprime ni encuentra los workflows dentro de él.

## 2. Configurar publicación y permisos

1. En el repositorio: **Settings → Pages → Build and deployment → Source → GitHub Actions**. No es necesario crear un segundo workflow de publicación; este paquete ya lo incluye.
2. En **Settings → Actions → General**, permita las acciones oficiales utilizadas: `actions/checkout`, `setup-python`, `upload-pages-artifact`, `configure-pages` y `deploy-pages`.
3. El YAML solicita `contents: write` sólo para el trabajo que guarda datos, y `pages: write` e `id-token: write` para publicar. No hace falta un token personal ni contraseña guardada. Si la cuenta u organización bloquea estos permisos, un administrador debe habilitarlos.
4. Si el guardado falla por una regla de protección de rama, deberá adaptar el proceso para guardar mediante una rama y revisión. No es necesario desactivar protecciones generales para publicar los datos iniciales.

## 3. Publicar la versión inicial

1. Abra **Actions**.
2. En el panel izquierdo seleccione **Actualizar y publicar dashboard IEPS**.
3. Pulse **Run workflow**, seleccione `main`, elija `publicar` y deje los otros campos vacíos.
4. Pulse **Run workflow** y abra la ejecución.
5. Deben terminar en verde los dos trabajos: **preparar** y **publicar**.
6. En **Settings → Pages** encontrará el enlace. Guárdelo: será la dirección del dashboard actualizado.

Si sólo está verde **preparar**, los datos están listos pero la publicación aún no terminó. Revise **publicar**. Este flujo publica en Pages dentro de la misma ejecución; no depende de que el commit automático dispare un segundo workflow.

## 4. Probar una actualización mensual

En **Actions → Actualizar y publicar dashboard IEPS → Run workflow**:

- `consulta`: **mensual**.
- `fecha`: **2026-10-10**, para consultar todos los días de septiembre de 2026.
- `ano`: vacío.

Después de ejecutarlo, revise el paso **Consultar, validar y regenerar**. Si tiene éxito, el resumen muestra el periodo, fuente y número de filas actualizadas; la base se guarda mediante un commit y se publica en la misma dirección. Septiembre completo equivale a 90 filas: 30 días × 3 combustibles.

Para futuros meses, deje `fecha` vacía para usar la fecha actual de Ciudad de México. Para reintentar un mes atrasado, ponga una fecha del mes siguiente al que quiere consultar.

Si la consulta falla, no se reemplaza el histórico de GitHub ni se publica una base parcial. Revise el mensaje: precio faltante, acuerdo no encontrado, complementario faltante, respuesta HTTP, o cambio de estructura. Un 403/502 desde una fuente oficial no se soluciona reemplazando datos por estimaciones. Corrija el acceso o el extractor y vuelva a ejecutar.

## 5. Probar las renuncias

Use **Run workflow** con `consulta = renuncias`, `ano = 2026` y fecha vacía. Debe recuperar el PDF de SHCP, extraer EF.DP.1 total y la columna 2026 con su porcentaje del PIB. La cifra ya incorporada al dashboard es 28,711 mdp y 0.0769%; el objetivo de esta prueba es comprobar la descarga desde GitHub.

Si SHCP bloquea el acceso, la tarea queda en rojo y conserva la cifra existente. Si el formato cambia, requiere revisar el extractor. El 1 de julio puede aún no estar publicada la edición del año: reintente cuando Hacienda la publique.

## 6. Probar la recaudación

Use **Run workflow**, elija `recaudacion` y deje fecha/año vacíos. La consulta selecciona el cuadro Ingresos Presupuestarios del Sector Público → Pesos corrientes multianual, periodicidad **Anual**, desde 2017 hasta el último año cerrado según el corte publicado. Descarga **Millones de pesos** y **Porcentajes del PIB**.

Si ambas descargas se validan, se actualizan juntas las dos gráficas, sus bases CSV/Excel y las fuentes. Si una falla, ninguna sustituye la base de GitHub. No se calcula el porcentaje con Banco Mundial ni con un PIB distinto del publicado en Presto. Los mensajes y, si existe, el artefacto `diagnostico-presto` permiten revisar el error.

## 7. Dejar el calendario funcionando

| Consulta | Calendario | Qué actualiza |
|---|---|---|
| Mensual | Día 10, 09:00 CDMX | Precios diarios del mes anterior, cuotas DOF y complementarios |
| Renuncias | 1 de julio, 09:00 CDMX | EF.DP.1 total y % del PIB de la edición vigente |
| Recaudación | 10 de enero, marzo, mayo, julio, septiembre y noviembre, 09:00 CDMX | Cierres anuales y revisiones, millones de pesos y % del PIB |

Los cron están escritos como `0 15 10 * *`, `0 15 1 7 *` y `0 15 10 1,3,5,7,9,11 *`: 15:00 UTC equivale a 09:00 en Ciudad de México. No tiene que mantener su computadora encendida.

GitHub puede retrasar ejecuciones y desactiva workflows programados en repositorios públicos tras 60 días sin actividad. La mensual mantiene actividad cuando guarda cambios; si falla varios meses, revise que el calendario siga habilitado. No se añadió una tarea diaria de mantenimiento.

Se incluyen las tres consultas; la descarga real de Presto todavía requiere validarse desde GitHub porque el portal respondió 502 durante esta entrega. Las consultas de precios o renuncias preservan la recaudación vigente.

Una vez que las consultas se hayan probado en GitHub, desactive las dos tareas anteriores de ChatGPT para evitar actualizaciones paralelas de archivos distintos. La versión descargada en su computadora es una instantánea; GitHub Pages muestra la última versión publicada.

## Documentación oficial

- Subir con Desktop: https://docs.github.com/en/desktop/overview/creating-your-first-repository-using-github-desktop
- Publicar con Actions: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- Calendarios: https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule
- Permisos: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository
